const o="优惠券",t={coupon:"优惠券"};export{o as coupon,t as default};
