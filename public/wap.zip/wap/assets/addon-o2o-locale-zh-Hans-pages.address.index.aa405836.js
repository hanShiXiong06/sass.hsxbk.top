const d="没有更多内容啦~",e="添加上门地址",s={default:"默认地址",noHomeAddress:d,addHomeAddress:e};export{e as addHomeAddress,s as default,d as noHomeAddress};
