import{bk as n}from"./index-f42fda90.js";async function o(o){n({url:o})}export{o as g};
