const e="创建时间：",t="卡项次数：不限次数",a="卡项次数：",c="去使用",m={createTime:e,cardNumNoLimit:t,cardNum:a,toUse:"去使用"};export{a as cardNum,t as cardNumNoLimit,e as createTime,m as default,c as toUse};
