import{bt as o}from"./index-2882a2d8.js";function e(){return o.get("phone_shop/goods/evaluate/config")}export{e as g};
