const e="订单编号",o="创建时间",r={orderNo:e,createTime:o};export{o as createTime,r as default,e as orderNo};
