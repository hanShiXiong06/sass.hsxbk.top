import{bu as t}from"./index-d8a8f699.js";function n(n){return t.get("tk_cps/cpsinfo",n)}function s(n){return t.get("tk_cps/actlist",n)}export{n as a,s as g};
