const e="请输入酒店名字",a="全部",l="价格",t={searchHotelName:e,all:"全部",price:"价格"};export{a as all,t as default,l as price,e as searchHotelName};
