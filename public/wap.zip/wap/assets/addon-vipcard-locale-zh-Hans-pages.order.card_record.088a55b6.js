const t="核销次数",a={verificationNum:t};export{a as default,t as verificationNum};
