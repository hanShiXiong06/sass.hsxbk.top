const e="充值记录",r="暂无充值记录",t={rechargeRecord:e,emptyTip:r};export{t as default,r as emptyTip,e as rechargeRecord};
