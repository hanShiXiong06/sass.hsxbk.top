const e="送给他的",i="您祝对方",o="对方已领取",t="礼品卡不存在",s={giveTipsOne:e,giveTipsTwo:i,otherReceive:o,notCard:t};export{s as default,e as giveTipsOne,i as giveTipsTwo,t as notCard,o as otherReceive};
