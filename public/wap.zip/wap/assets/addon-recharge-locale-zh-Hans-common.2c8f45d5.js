const o="订单号",e={orderNo:"订单号"};export{e as default,o as orderNo};
