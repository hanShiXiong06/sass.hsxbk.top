const e="退款金额",n="取消退款",t="撤销之后本次申请将会关闭,如后续仍有问题可再次发起申请。",d={refundMoney:e,refundApply:n,cancelRefundContent:t};export{t as cancelRefundContent,d as default,n as refundApply,e as refundMoney};
