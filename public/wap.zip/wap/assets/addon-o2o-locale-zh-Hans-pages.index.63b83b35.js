const e="请输入搜索关键词",r="抢购",a="没有更多内容啦~",o={searchNamePlaceholder:e,reserveBtn:"抢购",nothingMore:a};export{o as default,a as nothingMore,r as reserveBtn,e as searchNamePlaceholder};
