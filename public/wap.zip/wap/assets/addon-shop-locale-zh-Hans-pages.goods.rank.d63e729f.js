const a="榜单规则",e={rankingRules:a};export{e as default,a as rankingRules};
