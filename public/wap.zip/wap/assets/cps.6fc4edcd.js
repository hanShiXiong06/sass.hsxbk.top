import{bt as t}from"./index-2882a2d8.js";function n(n){return t.get("tk_cps/cpsinfo",n)}function s(n){return t.get("tk_cps/actlist",n)}export{n as a,s as g};
