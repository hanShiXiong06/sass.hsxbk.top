import{bg as o}from"./index-f42fda90.js";function e(){return o.get("shop/goods/evaluate/config")}export{e as g};
