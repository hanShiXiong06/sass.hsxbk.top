import{ak as r}from"./index-1a7efef0.js";function o(o){return r.post("pay",o,{showErrorMessage:!0})}function s(o,s,e){return r.get(`pay/info/${o}/${s}`,e,{showErrorMessage:!0})}export{s as g,o as p};
