const e="积分",t="元",d="已兑",i={point:"积分",priceUnit:"元",redeemed:"已兑"};export{i as default,e as point,t as priceUnit,d as redeemed};
