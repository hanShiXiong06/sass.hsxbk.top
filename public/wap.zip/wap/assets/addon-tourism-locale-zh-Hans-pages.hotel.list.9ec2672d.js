const e="请输入酒店名字",a="全部",l="起",r="价格",s={searchHotelName:e,all:"全部",rise:"起",price:"价格"};export{a as all,s as default,r as price,l as rise,e as searchHotelName};
