const t="返回详情",e="没有更多内容啦~",o={detail:t,nothingMore:e};export{o as default,t as detail,e as nothingMore};
