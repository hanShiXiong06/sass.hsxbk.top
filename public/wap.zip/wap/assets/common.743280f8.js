import"./index-905183d4.js";function t(t){const e=new Date(1e3*t);e.getFullYear(),e.getMonth(),e.getDate();const n=e.getHours(),o=e.getMinutes();return e.getSeconds(),`${n}:${o}`}export{t};
