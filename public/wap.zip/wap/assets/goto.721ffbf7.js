import{bC as n}from"./index-905183d4.js";async function o(o){n({url:o})}export{o as g};
