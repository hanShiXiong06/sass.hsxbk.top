const d="快递地址",e="同城配送地址",s="新建收货地址",a={address:d,locationAddress:e,createAddress:s,default:"默认"};export{d as address,s as createAddress,a as default,e as locationAddress};
