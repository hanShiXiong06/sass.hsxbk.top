import{b9 as o}from"./index-905183d4.js";function e(){return o.get("shop/goods/evaluate/config")}export{e as g};
