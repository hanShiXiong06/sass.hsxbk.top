import{bu as o}from"./index-d8a8f699.js";function e(){return o.get("phone_shop/goods/evaluate/config")}export{e as g};
