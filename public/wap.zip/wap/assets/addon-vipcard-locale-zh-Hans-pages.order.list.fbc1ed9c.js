const a="全部",e="实付金额",p="未获取到订单信息",t={all:"全部",payMoney:e,emptyTips:p};export{a as all,t as default,p as emptyTips,e as payMoney};
