const e="订单号",o="实付款",r="关闭订单",a="订单完成",t={orderNo:"订单号",actualPayment:"实付款",orderClose:r,orderFinish:a};export{o as actualPayment,t as default,r as orderClose,a as orderFinish,e as orderNo};
