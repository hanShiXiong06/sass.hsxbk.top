import{b9 as t}from"./index-905183d4.js";function n(n){return t.get("tk_cps/cpsinfo",n)}function s(n){return t.get("tk_cps/actlist",n)}export{n as a,s as g};
