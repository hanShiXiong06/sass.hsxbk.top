const e="请输入景点名称",a={searchScenicName:e};export{a as default,e as searchScenicName};
