const t="个人设置",o="切换语言",s="版本号",e="退出登录",n={personalSettings:t,switchLang:o,version:"版本号",logout:e};export{n as default,e as logout,t as personalSettings,o as switchLang,s as version};
