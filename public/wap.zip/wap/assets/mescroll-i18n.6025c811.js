const e={def:"zh",getType(){return uni.getStorageSync("mescroll-i18n")||this.def},setType(e){uni.setStorageSync("mescroll-i18n",e)}};export{e as m};
