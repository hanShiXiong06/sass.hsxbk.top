import{ak as t}from"./index-1a7efef0.js";function n(){return t.get("fast_pay/config/getconfig")}export{n as g};
