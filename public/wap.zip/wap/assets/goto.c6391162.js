import{bC as n}from"./index-2882a2d8.js";async function o(o){n({url:o})}export{o as g};
