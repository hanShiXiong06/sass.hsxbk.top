const a="任务说明",e="奖励规则",t={taskSpecification:a,rewardRules:e};export{t as default,e as rewardRules,a as taskSpecification};
