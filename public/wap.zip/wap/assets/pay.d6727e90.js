import{bg as r}from"./index-f42fda90.js";function o(o){return r.post("pay",o,{showErrorMessage:!0})}function s(o,s){return r.get(`pay/info/${o}/${s}`,{},{showErrorMessage:!0})}export{s as g,o as p};
