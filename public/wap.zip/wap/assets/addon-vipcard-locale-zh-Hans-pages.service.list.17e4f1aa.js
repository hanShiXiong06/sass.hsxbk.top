const e="请输入搜索关键词",a="抢购",r={searchNamePlaceholder:e,reserveBtn:"抢购"};export{r as default,a as reserveBtn,e as searchNamePlaceholder};
