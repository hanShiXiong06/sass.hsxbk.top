const a="请输入线路名字",e={searchWayName:a};export{e as default,a as searchWayName};
