const e="订单号",r="起",s="星级",t="星",a={orderNo:"订单号",rise:"起",starLevel:"星级",star:"星"};export{a as default,e as orderNo,r as rise,t as star,s as starLevel};
