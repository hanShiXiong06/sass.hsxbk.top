const t="文章详情",a="摘要",e="正在加载",d={detail:t,abstract:"摘要",loadingText:e};export{a as abstract,d as default,t as detail,e as loadingText};
