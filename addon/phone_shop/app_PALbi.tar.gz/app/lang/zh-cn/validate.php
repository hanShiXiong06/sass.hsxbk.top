<?php

return [
    'common_validate' => [
        'mobile' => '手机号格式有误',
    ],
];
