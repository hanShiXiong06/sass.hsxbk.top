
ALTER TABLE `shop_order_refund` ADD COLUMN `is_refund_delivery` INT(11) NOT NULL DEFAULT 0 COMMENT '是否退运费';
