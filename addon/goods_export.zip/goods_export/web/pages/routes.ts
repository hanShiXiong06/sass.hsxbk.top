export default [
    {
        path: "/goods_export/hello_world/index",
        component: () => import('~/addon/goods_export/pages/hello_world/index.vue')
    }
]
