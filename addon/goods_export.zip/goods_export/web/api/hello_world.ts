
/**
 * hello world
 */
export function getHelloWorld() {
    return request.get('goods_export/hello_world')
}

