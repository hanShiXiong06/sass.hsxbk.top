export default [
    {
        path: "/phone_shop_price/hello_world/index",
        component: () => import('~/addon/phone_shop_price/pages/hello_world/index.vue')
    }
]
