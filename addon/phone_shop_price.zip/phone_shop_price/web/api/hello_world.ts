
/**
 * hello world
 */
export function getHelloWorld() {
    return request.get('phone_shop_price/hello_world')
}

