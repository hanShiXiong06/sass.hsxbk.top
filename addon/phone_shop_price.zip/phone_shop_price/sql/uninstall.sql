DROP TABLE IF EXISTS `{{prefix}}phone_shop_recycle_order`;
DROP TABLE IF EXISTS `{{prefix}}phone_shop_recycle_category`;