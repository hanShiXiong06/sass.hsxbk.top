<?php
return [
    'pages' => <<<EOT
                // PAGE_BEGIN
                // *********************************** hello world ***********************************
                {
                    "path": "{{addon_name}}/pages/index",
                    "style": {
                        "navigationBarTitleText": "二手机回收报价单"
                    }
				},
                // PAGE_END
EOT
];
