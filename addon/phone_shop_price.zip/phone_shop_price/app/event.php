<?php

return [
    'bind' => [

    ],
    'listen' => [

    ],
    'subscribe' => [
    ],
];