<?php

return [
    'bind' => [

    ],
    'listen' => [
        'PayType' => [
            'addon\seafox_pay\app\listener\PayType'
        ],
        'PaySuccess' =>[
            'addon\seafox_pay\app\listener\PaySuccess'
        ],
        'RefundSuccess' => [
            'addon\seafox_pay\app\listener\RefundSuccess'
        ],
        'PayClose' => [
            'addon\seafox_pay\app\listener\PayClose'
        ]
    ],
    'subscribe' => [
    ],
];


