<?php

return [
    'drivers' => [
        // 海狐聚合支付
        'seafoxpay' => [
            'driver' => 'addon\seafox_pay\app\service\core\CoreSeafoxPayService',  //反射类的名字
            'app_key' => '',
            'secret_key' => '',
            'sign' => '',
        ],
    ]
];
