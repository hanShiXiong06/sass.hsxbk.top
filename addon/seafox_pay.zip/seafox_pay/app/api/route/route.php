<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的多应用管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

use app\api\middleware\ApiCheckToken;
use app\api\middleware\ApiLog;
use app\api\middleware\ApiChannel;
use think\facade\Route;


/**
 * 海狐聚合支付插件
 */
Route::group('seafox_pay', function() {
    /***************************************************** hello world ****************************************************/
    Route::get('hello_world', 'addon\seafox_pay\app\api\controller\hello_world\Index@index');
    /***************************************************** 买单相关 *************************************************/
    Route::get('maidan/info', 'addon\seafox_pay\app\api\controller\maidan\Index@Info');

    //买单订单创建
    Route::post('maidan/order', 'addon\seafox_pay\app\api\controller\maidan\Index@create');

    // 买单订单列表
    Route::get('maidan/order', 'addon\seafox_pay\app\api\controller\maidan\Index@lists');

    // 买单订单详情
    Route::get('maidan/order/:order_id', 'addon\seafox_pay\app\api\controller\maidan\Index@detail');

})->middleware(ApiChannel::class)
    ->middleware(ApiCheckToken::class, false) //false表示不验证登录
    ->middleware(ApiLog::class);



Route::group('seafox_pay', function() {

})->middleware(ApiChannel::class)
    ->middleware(ApiCheckToken::class, true) //表示验证登录
    ->middleware(ApiLog::class);

