<?php
declare (strict_types=1);

namespace addon\seafox_pay\app\listener;

/**
 *
 */
class PayType
{
    public function handle()
    {
        return [
            'seafoxpay' => [
                'name' => '海狐聚合支付',
                'key' => 'seafoxpay',
                'icon' => 'addon/seafox_pay/seafoxpay.png',
                'setting_component' => ''
            ]
        ];
    }
}
