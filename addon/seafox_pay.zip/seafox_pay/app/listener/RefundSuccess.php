<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的多应用管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\seafox_pay\app\listener;

/**
 * 支付退款异步回调事件
 */
class RefundSuccess
{

    // todo 
    public function handle(array $params)
    {
        $refund_no = $params['refund_no'] ?? '';
        $trade_type = $params['trade_type'] ?? '';
        $site_id = $params['site_id'] ?? '';
        $trade_id = $params['trade_id'] ?? '';
        return true;
    }

}