<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的saas管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\seafox_pay\app\service\admin;

use addon\seafox_pay\app\model\SeafoxPayFenzhangSet;
use core\base\BaseAdminService;
use addon\seafox_pay\app\model\SeafoxPayMerchant;
/**
 * 海狐聚合支付商户服务类
 * Class AgreementService
 * @package app\service\admin\sys
 */
class FenzhangSetService extends BaseAdminService
{

    public function __construct()
    {
        parent::__construct();
        $this->model = new SeafoxPayFenzhangSet();
    }

    public function getSet(array $params = array())
    {

        $merchant = $this->model::where(['merchant_id'=>$params['merchant_id']])->findOrEmpty()->toArray();
        if(empty($merchant)){
            $indata['site_id'] = $this->site_id;
            $indata['merchant_id'] = $params['merchant_id'];
            $this->model->strict(false)->insertGetId($indata);
            $merchant = $this->model::where(['merchant_id'=>$params['merchant_id']])->findOrEmpty()->toArray();
        }
        $merchant['fenlist'] = $merchant['fenlist']?json_decode($merchant['fenlist'],true):[];
        return $merchant;
    }

    public function saveSet(array $params = array())
    {

        $updata['open'] = $params['open'];
        $updata['fenlist'] = $params['fenlist']?json_encode($params['fenlist'],JSON_UNESCAPED_UNICODE):'';
     

        $this->model::where('merchant_id', $params['merchant_id'])->strict(false)->update($updata);
        return true;
    }

    public function selectmerlist(array $params = array())
    {
        $merchant = (new SeafoxPayMerchant())->where('site_id', $this->site_id)->select()->toArray();
        return $merchant;
    }



}