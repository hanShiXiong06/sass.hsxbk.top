<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的saas管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\seafox_pay\app\service\admin;

use addon\seafox_pay\app\model\SeafoxPayMerchant;
use core\base\BaseAdminService;

/**
 * 海狐聚合支付商户服务类
 * Class AgreementService
 * @package app\service\admin\sys
 */
class SeafoxPayMerchantService extends BaseAdminService
{
     
    public function __construct()
    {
        parent::__construct();
        $this->model = new SeafoxPayMerchant();
    }

    public function lists(array $params = array())
    {
        $where = [];
        if(!empty($params['name'])){
            $where[] = ['name','like','%'.$params['name'] ];
        }
        $where[] = ['site_id','=',$this->site_id];

        $count = $this->model::where($where)->select()->count();
        $lists = $this->model::where($where)->page($params['page'] , $params['limit'])->select()->toArray();
        return compact('lists','count');
    }

    public function delete(array $params = array())
    {
        $this->model::where(['id'=>$params['id']])->delete();
    }

    public function detail(array $params = array())
    {
        $merchant = $this->model::where(['id'=>$params['id']])->findOrEmpty()->toArray();
        return $merchant;
    }

    public function add(array $params = array())
    {
        $data = array(
            'mch_id' => $params['mch_id'],
            'name' => $params['name'],
            'logo' => $params['logo'],
            'addtime' => time()
        );
        $data['site_id'] = $this->site_id;
        $this->model::create($data);
    }

    public function edit(int $id, array $params = array())
    {
        $data = array(
            'mch_id' => $params['mch_id'],
            'name' => $params['name'],
            'logo' => $params['logo']
        );
        $this->model::where(['id'=>$id])->update($data);
    }

}