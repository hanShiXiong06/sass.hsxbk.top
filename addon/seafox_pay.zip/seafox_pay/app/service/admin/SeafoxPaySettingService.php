<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的saas管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\seafox_pay\app\service\admin;

use addon\seafox_pay\app\model\SeafoxPaySetting;
use core\base\BaseAdminService;

/**
 * 海狐聚合支付配置服务类
 * Class AgreementService
 * @package app\service\admin\sys
 */
class SeafoxPaySettingService extends BaseAdminService
{
     
    public function __construct()
    {
        parent::__construct();
        $this->model = new SeafoxPaySetting();
    }

    public function getConfig()
    {
        $config = $this->model::where(['site_id' => $this->site_id])->findOrEmpty()->toArray();
        if(empty($config)){
            $data = array(
                'site_id' => $this->site_id,
                'firstClassMerchantNo' => 'D10000000000056',
                'public_encryption' =>'sirqB98ZEKGeaFfgYDrymYIC',
                'public_autograph' => '3YmiCoO59WYno0ZraT9EhXMdfBBazPHB',
                'scancode_encryption' => 'spxaZ31AnOTtmm4jW7D9gLoo',
                'scancode_autograph' => 'b94TBQvh1eFsAXhMlpYqVMTANVkpisw0',
                'merchant_privateKey' => '',
                'merchant_cannelName' => 'WDSP',
                'receiptAppIds' => '',
                'app_product_wechat_qrcode' => 'http://qny.wdsp666.com/app/1656918379-%E6%8A%A5%E5%A4%87%E4%BA%8C%E7%BB%B4%E7%A0%81.jpg',
                'app_product_alipay_qrcode' => ''
            );
            $this->model::create($data);
            $config = $this->model::where(['site_id' => $this->site_id])->findOrEmpty()->toArray();
        }
        return $config;
    }

    public function setConfig(array $params = array())
    {
        $config = $this->model::where(['site_id' => $this->site_id])->findOrEmpty()->toArray();
        if(empty($config)){
            $data = array(
                'site_id' => $this->site_id,
                'firstClassMerchantNo' => $params['firstClassMerchantNo'] ?? '',
                'public_encryption' => $params['public_encryption'] ?? '',
                'public_autograph' => $params['public_autograph'] ?? '',
                'scancode_encryption' => $params['scancode_encryption'] ?? '',
                'scancode_autograph' => $params['scancode_autograph'] ?? '',
                'merchant_privateKey' => $params['merchant_privateKey'] ?? '',
                'merchant_cannelName' => $params['merchant_cannelName'] ?? '',
                'receiptAppIds' => $params['receiptAppIds'] ?? '',
                'app_product_wechat_qrcode' => $params['app_product_wechat_qrcode'] ?? '',
                'app_product_alipay_qrcode' => $params['app_product_alipay_qrcode'] ?? ''
            );
    
            $this->model::create($data);
        }else{
            $data = array(
                'firstClassMerchantNo' => $params['firstClassMerchantNo'] ?? '',
                'public_encryption' => $params['public_encryption'] ?? '',
                'public_autograph' => $params['public_autograph'] ?? '',
                'scancode_encryption' => $params['scancode_encryption'] ?? '',
                'scancode_autograph' => $params['scancode_autograph'] ?? '',
                'merchant_privateKey' => $params['merchant_privateKey'] ?? '',
                'merchant_cannelName' => $params['merchant_cannelName'] ?? '',
                'receiptAppIds' => $params['receiptAppIds'] ?? '',
                'app_product_wechat_qrcode' => $params['app_product_wechat_qrcode'] ?? '',
                'app_product_alipay_qrcode' => $params['app_product_alipay_qrcode'] ?? ''
            );
    
            $this->model::where(['site_id' => $this->site_id])->update($data);
        }

        return true;
    }

}