<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的saas管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\seafox_pay\app\service\admin;

use addon\seafox_pay\app\model\SeafoxPayMerchantCashRegister;
use Darabonba\OpenApi\Models\Config;
use addon\seafox_pay\app\model\SeafoxPayMerchantPart;
use addon\seafox_pay\app\model\SeafoxPaySetting;
use addon\seafox_pay\app\service\core\CoreImageService;
use addon\seafox_pay\app\service\core\SeafoxPayPart;
use AlibabaCloud\SDK\Ocrapi\V20210707\Models\RecognizeBusinessLicenseRequest;
use AlibabaCloud\SDK\Ocrapi\V20210707\Models\RecognizeIdcardRequest;
use AlibabaCloud\SDK\Ocrapi\V20210707\Ocrapi;
use AlibabaCloud\Tea\Utils\Utils\RuntimeOptions;
use core\base\BaseAdminService;
use core\exception\CommonException;
use Exception;

/**
 * 海狐聚合支付商户进件服务类
 * Class AgreementService
 * @package app\service\admin\sys
 */
class SeafoxPayMerchantPartService extends BaseAdminService
{

    public function __construct()
    {
        parent::__construct();
        $this->model = new SeafoxPayMerchantPart();
    }

    public static function getBaseInfo()
    {

        $settleBankTypeData = array(
            'TOPUBLIC'=>'对公',
            'TOPRIVATE'=>'对私',
        );

        $settlementPeriodData = array(
            'T1'=>'T1',
            'D1'=>'D1',
        );

        $settlementModeData = array(
            'NOTOPEN'=>'不开通',
            'AUTO'=>'自动结算',
            'SELF'=>'自主结算',
        );
        $merchantCategoryData = array(
            'FOOD_BEVERAGE'=>'餐饮/食品',
            'CAMPUS_GROUPMEAL'=> '校园团餐',
            'UNIVERSITIES_SECONDARY_CAMPUS'=> '高校和中职校园商户',
            'OFFLINE_RETAIL'=>'线下零售',
            'TICKETING_TRAVEL'=>'票务/旅游',
            'EDUCATION_TRAINING'=>'教育/培训',
            'LIFE_ADVISORY_SERVICE'=>'生活/咨询服务',
            'ENTERTAINMENT_FITNESS_SERVICES'=>'娱乐/健身服务',
            'MEDICAL_CARE'=>'医疗',
            'COLLECTION_AUCTION'=>'收藏/拍卖',
            'LOGISTICS_EXPRESS'=>'物流/快递',
            'COMMUNICATION'=>'通讯',
            'FINANCE_INSURANCE'=>'金融/保险',
            'NETWORK_VIRTUAL_SERVICE'=>'网络虚拟服务',
            'LIVING_PAYMENT'=>'生活缴费',
            'HOTEL'=>'酒店',
            'HOME_FURNISHING'=>'家居',
            'GROUP_PURCHASE'=>'电商团购',
            'LOTTERY'=>'彩票',
            'FASHION'=>'时尚',
            'UTILITIES_EXPENSE'=>'公共事业缴费',
            'REAL_ESTATE'=>'房地产',
            'TRANSPORTATION_SERVICE'=>'交通运输服务类',
            'MACHINE_ELECTRON'=>'机械/电子',
            'SOFTWARE'=>'软件',
            'DECORATION'=>'装饰',
            'GREEN_SEEDLING'=>'苗木/绿化',
            'MATERNAL_CHILD_PRODUCT'=>'母婴/玩具',
            'COLLECTION_PET'=>'收藏/宠物',
            'BOOK_STATIONERY_AUDIO_VIDEO'=>'书籍/音像/文具',
            'BUSINESS_PLATFORM'=>'平台商',
            'DIGITAL'=>'数码',
            'DIGITAL_ENTERTAINMENT'=>'数字娱乐',
            'ABROAD'=>'境外',
            'PREPAID_CARD'=>'预付卡',
            'DIRECT_SELLING'=>'直销',
            'CROWD_FUNDING'=>'众筹',
            'OTHER'=>'其他',
        );
        $settleModeData = array(
            'MERCHANT'=>'按商户结算',
            // 'MERGE'=>'按结算人结算',
        );

        $merchantTypeData = array(
            'ENTERPRISE'=>'企业商户',
            'INSTITUTION'=>'事业单位商户',
            'INDIVIDUALBISS'=>'个体工商户',
            'PERSON'=>'个人商户(小微商户)',
        );

        $industryTypeCodeData = array(
            '0' => '其它',
            '888' => '个人线下零售',
            '135' => '餐饮公司主体',
            '212' => '餐饮个体户',
        );

        $data = [
            'settleBankTypeData' => $settleBankTypeData,
            'settlementPeriodData' => $settlementPeriodData,
            'settlementModeData' => $settlementModeData,
            'merchantCategoryData' => $merchantCategoryData,
            'settleModeData' => $settleModeData,
            'merchantTypeData' => $merchantTypeData,
            'industryTypeCodeData' => $industryTypeCodeData
        ];

        return $data;
    }
    
    //商户进件
    public function parts($params)
    {
        extract($params);

        $imgData = $imgData ?? [];

        $seafoxpaySet = SeafoxPaySetting::where(['site_id' => $this->site_id])->findOrEmpty()->toArray();
        $helpmestoreInfo = self::getHelpMeStoreInfo($sid);
        if($helpmestoreInfo['orderNo'])
        {
            $orderNo = $helpmestoreInfo['orderNo'];
        }else{
            $orderNo = 'p_'.date('Ymd',time()).'_'.$sid.'_'.time();
        }

        $merchantNo = !empty($helpmestoreInfo['merchantNo']) ? $helpmestoreInfo['merchantNo'] : '';
        $helpmeDityCode = json_decode(file_get_contents(public_path().'addon/seafox_pay/helpmecity.json'),true);

        if(empty($area)){
            throw new CommonException('地区设置不能为空');
        }

        $province = $area[0] ?? '';
        $city = $area[1] ?? '';
        $district = $area[2] ?? '';

        $province = array_search($province,$helpmeDityCode);
        $city = array_search($city,$helpmeDityCode);
        $district = array_search($district,$helpmeDityCode);
        $bodyData = array(
            'merchantNo'=>$merchantNo,
            'helpmestore_id'=>$helpmestoreInfo['helpmestore_id'],
            //必填
            'sid'=>$sid,
            'firstClassMerchantNo'=>$seafoxpaySet['firstClassMerchantNo'],//商户编号 Y
            'orderNo'=>$orderNo,//商户订单号 Y
            'signName'=>$signName,//子商户签约名 Y
            'showName'=>$showName,//展示名（收银台展示名） Y
            'merchantType'=>$merchantType,//子商户类型 ENTERPRISE 企业商户 INSTITUTION 事业单位商户INSTITUTION 事业单位商户INDIVIDUALBISS  个体工商户 PERSON  个人商户(小微商户)
            'legalPerson'=>$legalPerson,//法人名字
            'legalPersonID'=>$legalPersonID,//法人身份证号
            'orgNum'=>$orgNum,//组织机构代码  1.若是个人商户，统一填写身份证号；2.三证合一，则统一填营业执照号
            'businessLicense'=>$businessLicense,//营业执照号
            'regionCode'=>$district,//区县编码 需填写县级编码（见附件行业编码及地区编码表.zip）
            'address'=>$address,//通讯地址
            'linkman'=>$linkman,//联系人
            'linkPhone'=>$linkPhone,//联系电话
            'email'=>$email,//联系邮箱
            'bankCode'=>$bankCode,//结算卡联行号
            'accountName'=>$accountName,//开户名
            'accountNo'=>$accountNo,//开户账号
            'updateBankCode'=>$updateBankCode ?? '',//结算卡联行号
            'updateAccountName'=>$updateAccountName ?? '',//开户名
            'updateAccountNo'=>$updateAccountNo ?? '',//开户账号
            'settleBankType'=>$settleBankType ?? '',//结算卡类型  对公：TOPUBLIC  对私：TOPRIVATE
            'settlementPeriod'=>$settlementPeriod ?? '',//结算类型
            'settlementMode'=>$settlementMode ?? '',//结算方式
            'merchantCategory'=>$merchantCategory ?? '',//经营类别 见附录5.5注：根据附录上传英文值，需和行业编码对应
            'settleMode'=>$settleMode ?? '',//结算模式 商户合并结算使用，按商户结算，正常结算： MERCHANT 按结算人结算，支持同平台商下，结算卡号一致的结算单合并成一笔出款：MERGE
            //必填 默认
            'authorizationFlag'=>'true',//授权使用平台商秘钥 true代表授权，false代表不授权注：平台密钥，通常默认为true
            'needPosFunction'=>'false',//是否需要开通 POS 功能
            'agreeProtocol'=>'true',//是否同意协议
            'idType'=>'IDCARD',//法人证件类型 具体值见附录5.37
            //非必填
            'webSite'=>'',//网站网址
            'accessUrl'=>'',//接入地址
            'province'=>'',//子商户所在省份
            'city'=>'',//子商户所在城市
            'bindMobile'=>'',//绑定手机
            'servicePhone'=>'',//客服联系电话
            'settlementRemark'=>'',//结算备注
            'unionPayQrCode'=>'',//银联二维码
            'idCardStartDate'=>'',//法人身份证开始日期 yyyyMMdd
            'idCardEndDate'=>'',//法人身份证结束日期 yyyyMMdd 或者长期有效
            'businessDateStart'=>'',//经营起始日期 yyyyMMdd
            'businessDateLimit'=>'',//经营期限 yyyyMMdd
            'accountIdCard'=>'',//开户人身份证
            'mcc'=>'',//银联 mcc 码
            'callbackUrl'=>'',//回调地址 人工审核后异步回调地址（返回参数为JSON数据）注：人工审核成功或失败会异步通知；自动审核通过，不会通知
            'settlementAuth'=>'',//结算信息鉴权
            'postalAddress'=>'',//注册地址
            'microBizType'=>'',//小微经营类型
            'certType'=>'',//证书类型
            'linkManId'=>'',//联系人身份证号
            'needAuthorize'=>'',//是否需要认证
            'specialSignName'=>'',//是否需要特殊处理商户名称
            'longitude'=>'',//经度
            'latitude'=>'',//纬度
            'electronicAccountNo'=>'',//电子账户
            'settleChangeType'=>'',//结算到账方式
            'settlementIdCardNo'=>'',//结算人身份证号
            'settlementPhoneNo'=>'',//结算人手机号
            'serviceCodes'=>'',//支付宝商
        );
        if($merchantNo)
        {
            $bodyData['orderNo'] = 'p_'.date('YmdHis').rand(1000,9999).'_'.$sid;
            $up_url = "https://payment.dinpay.com/trx/api/merchantEntryAlteration/modifyMerchantInfo";
            $interfaceName = 'modifyMerchantInfoV2';
        }else{
            $bodyData['industryTypeCode'] = $industryTypeCode;//行业类型编码 见附件(行业编码及地区编码表.zip)注：个人商户类型不用填写，其他类型必传
            $up_url = "https://payment.dinpay.com/trx/merchantEntry/interface.action";
            $interfaceName = 'register';
        }

        $bodyData = array_filter($bodyData);
        $res = (new SeafoxPayPart())->bodyDataHandle($bodyData, $interfaceName, $up_url);
        if($res['code'] != '0000')
        {
            throw new CommonException($res['message']);
        }else{
            $encryptClass = new SeafoxPayPart();
            $data = isset($res['data']) ? $encryptClass->decrypt($res['data']) : array('orderNo' => '');
            $orderNo = $data['orderNo'];
            if($helpmestoreInfo)
            {
                // unset($bodyData['orderNo']);
                if($orderNo){
                    $bodyData['orderNo'] = $orderNo;
                }
                SeafoxPayMerchantPart::where(['sid' => $sid])->update($bodyData);
            }else{
                $bodyData['firstClassMerchantNo'] = $bodyData['firstClassMerchantNo'] ?? '';
                SeafoxPayMerchantPart::create($bodyData);
            }
            if($orderNo) {
                self::imageUrlUploadAfterParts($orderNo, $imgData ,$this->site_id);
            }

            return ['st' => 1, 'msg' => '进入资质上传'];
        }
    }

    //进件顺带上传资质
    public static function imageUrlUploadAfterParts($orderNo, $imgData ,$site_id)
    {
        foreach ($imgData as $key => $value) {
            if($value) {
                $bodyData = [
                    'orderNo'=>$orderNo,
                    'credentialUrl'=>(new CoreImageService())->thumb($site_id, $value, 'small'),
                    'credentialType'=>$key,//法人身份证正面 FRONT_OF_ID_CARD   法人身份证反面 BACK_OF_ID_CARD
                ];
                $interfaceName = 'uploadImageUrl';
                $url = "https://payment.dinpay.com/trx/merchantEntry/interface.action";
                (new SeafoxPayPart())->bodyDataHandle($bodyData, $interfaceName, $url);
            }
        }
    }

    //资质上传
    public function imageUrlQuery($params)
    {
        extract($params);

        $helpMeStoreInfo = self::getHelpMeStoreInfo($sid);
        $merchantNo = $helpMeStoreInfo->merchantNo;

        $imgs = $imgs ?? [];

        if(!$imgs){
            throw new CommonException('请传入图片');
        }

        $params['type'] = 'imageUrlQuery';
        $is_null = 1;
        $imageResult = self::getInfoByType($params);
        foreach ($imageResult as $key => $value) {
            if($value && $value != 'http://qny.wdsp666.com/?imageMogr2/thumbnail/300x')
                $is_null = 0;
        }

        if($is_null == 1) {
            $interfaceName = 'uploadImageUrl';
        }else {
            $interfaceName = 'imageUrlAlteration';
        }
        $url = "https://payment.dinpay.com/trx/merchantEntry/interface.action";

        foreach($imgs as $credentialType => $credentialUrl)
        {
            $credentialUrl = (new CoreImageService())->thumb($this->site_id, $credentialUrl, 'small');
            // $orderNo = 'p_'.date('YmdHis').rand(1000,9999); 
            $bodyData = [
                'orderNo'=>$helpMeStoreInfo->orderNo,
                'merchantNo'=>$merchantNo,
                'credentialUrl'=>$credentialUrl,
                'credentialType'=>$credentialType,//法人身份证正面 FRONT_OF_ID_CARD   法人身份证反面 BACK_OF_ID_CARD
            ];
            (new SeafoxPayPart())->bodyDataHandle($bodyData, $interfaceName, $url);
        }
    }

    //产品开通
    public static function productQuery($params)
    {
        extract($params);

        $helpMeStoreInfo = self::getHelpMeStoreInfo($sid);
        $merchantNo = $helpMeStoreInfo->merchantNo;
        
        $bodyData = [
            'merchantNo'=>$merchantNo,
            'activityId'=>$feePurpose,
        ];

        $up_url = "https://payment.dinpay.com/trx/merchantEntry/interface.action";
        $interfaceName = 'activityApplyQuery';
        $res = (new SeafoxPayPart())->bodyDataHandle($bodyData, $interfaceName, $up_url);
        if($res['code'] != '0000' && $value < 0.23){
            throw new CommonException('费率必须大于或等于0.23');
        }

        if($payType == 'ACCOUNT_PAY') {
            $bodyData = [
                'productType' => 'ACCOUNT_PAY',
                'firstClassMerchantNo' => $helpMeStoreInfo['firstClassMerchantNo'],
                'merchantNo' => $merchantNo,
                'calcType' => 'SINGLE',
                'value' => 0.00,
                'minFee' => 0.00,
            ];
        }else {
            $bodyData = [
                'productType'=>'APPPAY',//产品类型 扫码产品:APPPAY
                'firstClassMerchantNo'=> $helpMeStoreInfo['firstClassMerchantNo'],//平台商编号
                'merchantNo'=> $merchantNo,//子商户编号
                'appPayType'=> $appPayType,//客户端类型
                'payType'=> $payType,//支付类型 SWIPE    刷卡SCAN  扫码WAP   WAPPUBLIC   公众号支付SDK    SDKAPPLET   小程序
                'value'=> $value,//费率
                'minFee'=> $minFee ?? 0.01,//最低费率金额
                // 'appFeeMode'=> $appFeeMode,//费率模式
                'feePurpose'=> $feePurpose,//费率类型
                'feeRanges'=> $feeRanges,
            ];
        }
        $interfaceName = 'openProduct';
        $res = (new SeafoxPayPart())->bodyDataHandle($bodyData, $interfaceName, $up_url);
        if($res['code'] != '0000')
            throw new CommonException($res['message']);
        else
            return ['st' => 1, 'msg' => '进入app报备'];
    }

    //app报备
    public function appapplyqueryAll($params)
    {
        extract($params);
        if(in_array($appPayType ?? '', ['ALIPAY', 'WXPAY'])) {
            return $this->queryApplyByType($merchantNo, $orderNo, $appPayType);
        }else {
            $weixin = $this->queryApplyByType($merchantNo, $orderNo, 'WXPAY');
            $alipay = $this->queryApplyByType($merchantNo, $orderNo, 'ALIPAY');
            return [$weixin, $alipay];
        }
    }

    //报备
    public static function applyByType($merchantNo, $appPayType)
    {
        $bodyData = [
            'merchantNo'=>$merchantNo,//进件下单时的订单号
            'orderNo'=>'app_'.date("YmdHis",time()).rand(10000,99999),//进件下单时的订单号
            'appPayType'=>$appPayType,//ALIPAY  支付宝 WXPAY   微信支付
        ];

        $url = "https://payment.dinpay.com/trx/merchantEntry/interface.action";
        $interfaceName = 'appApply';
        $res = (new SeafoxPayPart())->bodyDataHandle($bodyData, $interfaceName, $url);

        $encryptClass = new SeafoxPayPart();
        $result = isset($res['data']) ? $encryptClass->decrypt($res['data']) : array();
        return $result;
    }

    //报备查询
    public function queryApplyByType($merchantNo, $orderNo, $appPayType)
    {   
        $bodyData = [
            'merchantNo' => $merchantNo,//进件下单时的订单号
            'orderNo' => $orderNo,//进件下单时的订单号
            'appPayType'=> $appPayType,//ALIPAY 支付宝 WXPAY   微信支付
        ];
        $interfaceName = 'appApplyQuery';
        $url = "https://payment.dinpay.com/trx/merchantEntry/interface.action";
        $res = (new SeafoxPayPart())->bodyDataHandle($bodyData, $interfaceName, $url);
        $encryptClass = new SeafoxPayPart();
        $result = isset($res['data']) ? $encryptClass->decrypt($res['data']) : array();
        return $result;
    }

    //微信进件
    public function wxPublicApplyQuery($params)
    {
        extract($params);

        $helpMeStoreInfo = self::getHelpMeStoreInfo($sid);
        $merchantNo = $helpMeStoreInfo['merchantNo'];
        $orderNo = $helpMeStoreInfo['orderNo'];
        $seafoxpaySet = SeafoxPaySetting::where(['site_id' => $this->site_id])->findOrEmpty()->toArray();

        $interfaceName = 'wxPublicApply';
        $url = "https://payment.dinpay.com/trx/merchantEntry/interface.action";
        $bodyData = [
            'merchantNo'=>$merchantNo,
            'appIds'=>explode(',', $appIds),//支付公众号列表
            'authPayDirs'=>explode(',', $authPayDirs),//支付授权目录列表（url 格式参考微信公众号文档https://pay.weixin.qq.com/wiki/doc/api/jsapi.php?chapter=7_3）
            'merchantChannelName'=>$seafoxpaySet['merchant_cannelName'],//渠道名
            'orderNo'=>$orderNo,//请求单号
            // 'operateType'=>'MODIFY',//修改操作 MODIFY 重复报备操作 REPEAT
        ];
        if($wechat_type == 'subscribe')
            $bodyData['subscribeAppIds'] = explode(',', $subscribeAppIds);//关注公众号列表(与关注小程序列表二选一)
        if($wechat_type == 'receipt')
            $bodyData['receiptAppIds'] = explode(',', $appIds);//关注公众号列表(与关注小程序列表二选一)
        $res = (new SeafoxPayPart())->bodyDataHandle($bodyData, $interfaceName, $url);

        if($res['code'] != '0000') {
            throw new CommonException($res['message']);
        }

        return [];
    }

    //获取信息
    public function getInfoByType($params)
    {
        extract($params);
        $helpmestoreInfo = self::getHelpMeStoreInfo($sid);
        $url = "https://payment.dinpay.com/trx/merchantEntry/interface.action";

        $interfaceName = 'registerQuery';
        if($helpmestoreInfo['orderNo'])
            $orderNo = $helpmestoreInfo['orderNo'];
        else
            $orderNo = 'p_20220630_'.$sid.'_'.time();
        $bodyData = [
            'orderNo' => $orderNo,//进件下单时的订单号
            'firstClassMerchantNo' => $helpmestoreInfo['firstClassMerchantNo'],
        ];
        
        $res = (new SeafoxPayPart())->bodyDataHandle($bodyData, $interfaceName, $url);
        $encryptClass = new SeafoxPayPart();
        $helpstore = isset($res['data']) ? $encryptClass->decrypt($res['data']) : array('orderNo' => '' , 'merchantNo' => '' ,'province' => '' ,'city' =>'', 'county' => '');

        //判断信息有无merchantNo
        $record = SeafoxPayMerchantPart::where(['orderNo' => $helpstore['orderNo']])->find();
        if($record && !$record['merchantNo']) {
            $record->merchantNo = $helpstore['merchantNo'] ?? '';
            $record->save();
        }

        // if(empty($helpstore['merchantNo'])){
        //     throw new CommonException('未审核通过，请等待通道返回商户号');
        // }
        
        switch ($type) {
            case 'parts':
                //商户进件
                $helpstore['address_code']['province'] = $helpstore['province'];
                $helpstore['address_code']['city'] = $helpstore['city'];
                $helpstore['address_code']['district'] = $helpstore['county'];

                return $helpstore;
                break;
            case 'imageUrlQuery':
                //资质上传
                $key = $sid.'_imageUrls';
                $credentialTypes = [ 
                    'FRONT_OF_ID_CARD'=>'法人身份证正面',
                    'BACK_OF_ID_CARD'=>'法人身份证反面',
                    'BUSINESS_LICENSE'=>'营业执照',
                    'PERMIT_FOR_BANK_ACCOUNT'=>'开户许可证',
                    'SIGN_BOARD'=>'商户门头照',
                    'INTERIOR_PHOTO'=>'商户室内照',
                    'AUTHORIZATION_FOR_SETTLEMENT'=>'结算账户指定书',
                    'HANDHELD_OF_ID_CARD'=>'手持身份证照',
                    'HANDHELD_OF_BANK_CARD'=>'手持银行卡照正面',
                    'BANK_CARD'=>'结算卡',
                    'SETTLE_FRONT_OF_ID_CARD'=>'结算人身份证正面',
                    'SETTLE_BACK_OF_ID_CARD'=>'结算人身份证反面',
                ];
                $imageUrls = [];
                foreach($credentialTypes as  $credentialType => $value)
                {
                    $bodyData = array(
                        'merchantNo'=>$helpstore['merchantNo'] ?? '',
                        'orderNo'=>$helpstore['orderNo'] ?? '',
                        'credentialType'=>$credentialType,//法人身份证正面 FRONT_OF_ID_CARD   法人身份证反面 BACK_OF_ID_CARD
                    );
                    $res = (new SeafoxPayPart())->uploadImageUrl($bodyData, $url);
                    $resultData = isset($res['data']) ? $encryptClass->decrypt($res['data']) : array('credentialUrl' => '');
                    $imageUrls[$credentialType] = $resultData['credentialUrl'] ?? '';
                }
                return $imageUrls;
                break;
            case 'productQuery':
                //产品开通
                $bodyData = array(
                    'productType'=>'APPPAY',
                    'firstClassMerchantNo'=>$helpmestoreInfo['firstClassMerchantNo'],
                    'merchantNo'=>$helpstore['merchantNo'] ?? '',
                    'orderNo'=>$helpstore['orderNo'] ?? '',
                    'payType'=>'SCAN',
                    'appPayType'=>'WXPAY',
                );
                $interfaceName = 'productQuery';
                $res = (new SeafoxPayPart())->bodyDataHandle($bodyData, $interfaceName, $url);
                $products =  isset($res['data']) ? $encryptClass->decrypt($res['data']) : array();
                return $products;
                break;
            case 'appapplyquery':
                //app报备
                $bodyData = [
                    'merchantNo'=>$helpstore['merchantNo']  ?? '',//进件下单时的订单号
                    'orderNo'=>$helpmestoreInfo['orderNo'],//进件下单时的订单号
                ];
                $merchantNo = $bodyData['merchantNo'];
                $orderNo = $bodyData['orderNo'];
                $data = [];
                switch ($appPayType) {
                    case 'WXPAY':
                        $wechat = self::queryApplyByType($merchantNo, $orderNo, $appPayType);
                        $data['result'] = $wechat;
                        break;
                    case 'ALIPAY':
                        $alipay = self::queryApplyByType($merchantNo, $orderNo, $appPayType);
                        $data['result'] = $alipay;
                        break;
                    default:
                        $wechat = self::queryApplyByType($merchantNo, $orderNo, 'WXPAY');
                        $alipay = self::queryApplyByType($merchantNo, $orderNo, 'ALIPAY');
                        $data['result'] = [
                            'wechat' => $wechat,
                            'alipay' => $alipay
                        ];
                        break;
                }
                $data['merchantNo'] = $bodyData['merchantNo'];
                $authorizeStatusCn = [
                    'PRE_AUTHORIZED'=>'待授权',
                    'AUTHORIZED'=>'已授权',
                    'NOT_AUTHORIZED'=>'未授权',
                    'AUTHORIZED_FAIL'=>'授权失败',
                ];

                $data['authorizeStatusCn'] = $authorizeStatusCn;
                return $data;
                break;
            case 'wxPublicApplyQuery':
                $seafoxpaySet = SeafoxPaySetting::where(['site_id' => $this->site_id])->findOrEmpty()->toArray();
                //微信进件
                $bodyData = array(
                    'merchantNo'=>$helpstore['merchantNo']  ?? '',
                    'merchantChannelName'=>$seafoxpaySet['merchant_cannelName'],
                    'orderNo'=>$helpstore['orderNo'],//请求单号
                    'receiptAppIds'=>array($seafoxpaySet['receiptAppIds']),
                );

                $interfaceName = 'wxPublicApplyQuery';
                $res = (new SeafoxPayPart())->bodyDataHandle($bodyData, $interfaceName, $url);

                $wxPublicApplyData = isset($res['data']) ? $encryptClass->decrypt($res['data']) : array();

                if(isset($wxPublicApplyData['appIds']))
                    $wxPublicApplyData['appIds'] =implode(',',  json_decode(htmlspecialchars_decode($wxPublicApplyData['appIds'])));

                if(isset($wxPublicApplyData['authPayDirs']))
                    $wxPublicApplyData['authPayDirs'] =implode(',',  json_decode(htmlspecialchars_decode($wxPublicApplyData['authPayDirs'])));

                return $wxPublicApplyData;
                break;
            case 'bindorauth':
                //代运营授权绑定
                $operateType = 'OPERATION_AUTH';

                $bodyData = array(
                    'orderNo'=>$helpstore['orderNo'] ?? '',
                    'merchantNo'=>$helpstore['merchantNo'] ?? '',//进件下单时的订单号
                    'operateType'=>$operateType,
                );
                $interfaceName = 'bindOrAuthAlipayAccountQuery';
                $res = (new SeafoxPayPart())->bodyDataHandle($bodyData, $interfaceName, "https://payment.dinpay.com/trx/merchantEntry/interface.action");
                $result = isset($res['data']) ? $encryptClass->decrypt($res['data']) : array('paramDetails' =>'','operateType' => '');

                $paramDetails = $result['paramDetails'];
                $operateType = $result['operateType'];

                $authorizeStatusCn = [
                    'AUTHORIZED'=>'已授权',
                    'NOT_AUTHORIZED'=>'未授权',
                    'AUTHORIZED_FAIL'=>'商户超时未确认',
                ];
                return ['merchantNo' => $bodyData['merchantNo'], 'paramDetails' => $paramDetails, 'operateType' => $operateType, 'authorizeStatusCn' => $authorizeStatusCn];
                break;
            case 'cardalteration':
                return $helpstore;
                break;
            case 'modifyMerchantInfo':
                return $helpstore;
                break;
            case 'activityApply':
                return $helpstore;
                break;
            case 'activityApplyUrl':
                //活动资质报名
                $credentialTypes = [ 
                    'SIGN_BOARD_ACTIVITY'=>'门头照_活动报名',
                    'INTERIOR_PHOTO_ACTIVITY'=>'室内照_活动报名',
                    'MERCHANT_ENTERPRISE_MEALS_COOPERATION'=>'商户与企业团餐合作协议(支付宝)',
                    'PRIVATE_NONENTERPRISE_UNITS'=>'民办非企业单位登记证书图片',
                    'CERTIFICATE_FILE'=>'证明文件图片',
                    'ACTIVITY_RATE_COMMITMENT'=>'优惠费率承诺函照',
                    'RUN_SCHOOL_LICENSE_PIC'=>'办学资质图片',
                    'INSTITUTIONAL_ORGANIZATION_PIC'=>'法人登记证书',
                ];

                if(empty($imageUrls))
                {
                    $imageUrls = [];
                    foreach($credentialTypes as  $credentialType => $value)
                    {
                        $bodyData = [
                            'orderNo'=>$helpstore['orderNo'] ?? '',
                            'merchantNo'=>$helpstore['merchantNo'] ?? '',
                            'credentialType'=>$credentialType,//法人身份证正面 FRONT_OF_ID_CARD   法人身份证反面 BACK_OF_ID_CARD
                        ];
                        $res = (new SeafoxPayPart())->uploadImageUrl($bodyData, "https://payment.dinpay.com/trx/merchantEntry/interface.action");
                        $resultData = isset($res['data']) ? $encryptClass->decrypt($res['data']) : array('credentialUrl' => '');
                        $imageUrls[$credentialType] = $resultData['credentialUrl'] ?? '';
                    }
                }

                return $imageUrls;
                break;
            case 'activityApplyQuery':
                //活动报名查询
                $activityId = $activityId ? $activityId : 'SCHOOLCANTEEN_001';

                $activityApplyStatus = array(
                    'INIT'=>'初始化',
                    'AUDITING'=>'审核中',
                    'PASS'=>'报名通过',
                    'REJECT'=>'审核驳回',
                    'MODIFY'=>'报名修改',
                );

                $bodyData = array(
                    'orderNo'=>$helpstore['orderNo'] ?? '',
                    'merchantNo'=>$helpstore['merchantNo'] ?? '',
                    'activityId'=>$activityId,
                );

                $up_url = 'https://payment.dinpay.com/trx/merchantEntry/interface.action';
                $interfaceName = 'activityApplyQuery';
                $res = (new SeafoxPayPart())->bodyDataHandle($bodyData, $interfaceName, $up_url);
                if($res['code'] != '0000') {
                    throw new CommonException($res['message']);
                }else{
                    $activityInfo = isset($res['data']) ? $encryptClass->decrypt($res['data']) : array('paramDetails' => '');
                    $paramDetails = $activityInfo['paramDetails'];

                    foreach ($paramDetails as $key => $value) {
                        $paramDetails[$key]['activityApplyStatus'] = $activityApplyStatus[$value['activityApplyStatus']];
                    }

                    return $paramDetails;
                }
                break;
            case 'modifyProductConfig':
                //产品手续费收取方式
                $bodyData = [
                    'orderNo'=>$helpstore['orderNo'] ?? '',
                    'merchantNo'=>trim($helpstore['merchantNo'] ?? ''),
                    'type'=>'FeeCollection',
                    'productType'=>'APPPAY',
                ];

                $interfaceName = 'getProductConfig';
                $res = (new SeafoxPayPart())->bodyDataHandle($bodyData, $interfaceName, "https://payment.dinpay.com/trx/merchantEntry/interface.action");
                $productConfig = isset($res['data']) ? $encryptClass->decrypt($res['data']) : array();

                return $productConfig;
                break;
            case 'aliSubMerchantUpdate':
                $helpMeStoreInfo = self::getHelpMeStoreInfo($sid);
                $merchantNo = $helpMeStoreInfo->merchantNo ?? '';
                $orderNo = $helpMeStoreInfo->orderNo ??'';

                $alipay = self::queryApplyByType($merchantNo, $orderNo, 'alipay');

                $subMerchantNo = $alipay['threePartnerNoData'][1]['threePartnerNo'] ?? '';

                if($subMerchantNo) {
                    $bodyData = array(
                        'firstClassMerchantNo' => $helpMeStoreInfo->firstClassMerchantNo,
                        'subMerchantNo'=>$subMerchantNo,
                    );

                    $up_url = 'https://payment.dinpay.com/trx/merchantEntry/interface.action';
                    $interfaceName = 'aliSubMerchantQuery';
                    $res = (new SeafoxPayPart())->bodyDataHandle($bodyData, $interfaceName, $up_url);
                    $data = isset($res['data']) ? $encryptClass->decrypt($res['data']) : array('mcc' => '');

                    $helpstore['current_mcc'] = $data['mcc'];
                    $helpstore['subMerchantNo'] = $subMerchantNo;
                }else {
                    $helpstore['current_mcc'] = '';
                    $helpstore['subMerchantNo'] = '';
                }

                return $helpstore;
                break;
            case 'appapplyqueryAll':
                $merchantNo = $helpstore['merchantNo'] ?? '';
                $orderNo = $helpstore['orderNo'] ?? '';;
                $data = compact(
                    'merchantNo', 
                    'orderNo'
                );
                $list = self::appapplyqueryAll($data);

                return $list;

                break;
            default:
                throw new CommonException('类型有误');
                break;
        }
    }

    //二级商户修改(支)
    public static function aliSubMerchantUpdate($params)
    {
        extract($params);

        $helpMeStoreInfo = self::getHelpMeStoreInfo($sid);
        $merchantNo = $helpMeStoreInfo->merchantNo;

        $up_url = "https://payment.dinpay.com/trx/merchantEntry/interface.action";
        $bodyData = array(
            'merchantNo'=>$merchantNo,
            'subMerchantNo'=>$subMerchantNo,
            'mcc'=>$mcc,
        );

        $interfaceName = 'aliSubMerchantUpdate';
        $res = (new SeafoxPayPart())->bodyDataHandle($bodyData, $interfaceName, $up_url);

        if($res['code'] != '0000') {
            throw new CommonException($res['message']);
        }else {
            return '修改成功';
        }
    }

    //代运营授权绑定
    public static function bindorauth($params)
    {
        extract($params);

        $helpMeStoreInfo = self::getHelpMeStoreInfo($sid);
        $merchantNo = $helpMeStoreInfo->merchantNo;
        $url = "https://payment.dinpay.com/trx/merchantEntry/interface.action";

        $operateType = $operateType ?? 'OPERATION_AUTH';
        $confirmSceneType = $confirmSceneType ?? 'OFFLINE';

        $is_update = 0;
        if($is_update == 1)
        {
            $bodyData = [
                'merchantNo'=>$merchantNo,//进件下单时的订单号
                'alipayAccount'=>$alipayAccount,//商户支付宝登录账号
                // 'operateType'=>$_GPC['operateType'],//ACCOUNT_BIND   账号绑定 OPERATION_AUTH 代运营授权
                // 'confirmSceneType'=>$_GPC['confirmSceneType'],//ONLINE   线上 OFFLINE  线下
            ];
            $interfaceName = 'bindOrAuthAlipayAccountUpdate';
        }else{
            $bodyData = [
                'merchantNo'=>$merchantNo,//进件下单时的订单号
                'alipayAccount'=>$alipayAccount,//商户支付宝登录账号
                'operateType'=>$operateType,//ACCOUNT_BIND  账号绑定 OPERATION_AUTH 代运营授权
                'confirmSceneType'=>$confirmSceneType,//ONLINE  线上 OFFLINE  线下
            ];
            $interfaceName = 'bindOrAuthAlipayAccount';
        }
        (new SeafoxPayPart())->bodyDataHandle($bodyData, $interfaceName, $url);
        return '操作成功';
    }

    //结算卡信息变更
    public static function cardalteration($params)
    {
        extract($params);

        $helpMeStoreInfo = self::getHelpMeStoreInfo($sid);
        $merchantNo = $helpMeStoreInfo->merchantNo;
        $orderNo = $helpMeStoreInfo->orderNo.time().rand(1000,9999);
       
        $fileSigns = [
            'authorizationForSettlement'=>$authorizationForSettlement ?: false,
            'frontOfIdCard'=>$frontOfIdCard ?: false,//持卡人身份证正面照
            'backOfIdCard'=>$backOfIdCard ?: false,//持卡人身份证反面照
            'handheldOfIdCard'=>$handheldOfIdCard ?: false,//持卡人手持身份证照
            'handheldOfBankCard'=>$handheldOfBankCard ?: false,//持卡人手持银行卡照
            // 'accountOpeningCertificate'=>'',
            // 'subleaseCertificate'=>'',
            // 'permitForBankAccount'=>'',
            // 'bankCard'=>'',
        ];
        $file = [];
        foreach ($fileSigns as $key => $value) {
            if($value) {
                $fileSigns[$key] = md5(file_get_contents($value));
                $file[$key]= file_get_contents($value);
            }
        }

        $up_url = "https://payment.dinpay.com/trx/merchantEntry/upload.action";

        $bodyData = [
            'merchantNo'=>$merchantNo,
            'orderNo'=>$orderNo,//商户订单号 Y
            'bankCode'=>$bankCode,//结算卡联行号
            'accountName'=>$accountName,//开户名
            'accountNo'=>$accountNo,//开户账号
            'updateBankCode'=>$updateBankCode ?? '',//结算卡联行号
            'updateAccountName'=>$updateAccountName  ?? '',//开户名
            'updateAccountNo'=>$updateAccountNo  ?? '',//开户账号
            'settleBankType'=>$settleBankType  ?? '',//结算卡类型  对公：TOPUBLIC  对私：TOPRIVATE
            'settlementPeriod'=>$settlementPeriod  ?? '',//结算类型
            'settlementMode'=>$settlementMode  ?? '',//结算方式
            // 'merchantCategory'=>$_GPC['merchantCategory'],//经营类别 见附录5.5注：根据附录上传英文值，需和行业编码对应
            'settleMode'=>$settleMode  ?? '',//结算模式 商户合并结算使用，按商户结算，正常结算： MERCHANT 按结算人结算，支持同平台商下，结算卡号一致的结算单合并成一笔出款：MERGE
            'merchantEntryAlterationType'=>'SETTLE_BANKCARD',
            'fileSigns'=>$fileSigns,
        ];
        $interfaceName = 'settlementCardAlteration';
        $bodyData = array_filter($bodyData);
        $res = (new SeafoxPayPart())->bodyDataHandle($bodyData, $interfaceName, $up_url, $file);

        if($res['code'] != '0000') {
            throw new CommonException($res['message']);
        }else 

        return '修改成功';
    }

    //商户信息修改
    public function modifyMerchantInfo($params)
    {
        extract($params);
        
        $helpMeStoreInfo = self::getHelpMeStoreInfo($sid);
        $merchantNo = $helpMeStoreInfo->merchantNo;
        $orderNo = $helpMeStoreInfo->orderNo.time().rand(1000,9999);
        $helpmestore_id = $helpMeStoreInfo->helpmestore_id;
        
        $helpmeDityCode = json_decode(file_get_contents(public_path().'addon\seafox_pay\helpmecity.json'),true);
        if(empty($area)){
            throw new CommonException('地区设置不能为空');
        }

        $province = $area[0] ?? '';
        $city = $area[1] ?? '';
        $district = $area[2] ?? '';

        $province = array_search($province,$helpmeDityCode);
        $city = array_search($city,$helpmeDityCode);
        $district = array_search($district,$helpmeDityCode);

        $up_url = "https://payment.dinpay.com/trx/merchantEntry/upload.action";
        $seafoxpaySet = SeafoxPaySetting::where(['site_id' => $this->site_id])->findOrEmpty()->toArray();
        
        $bodyData = [
            'merchantNo'=>$merchantNo,
            'helpmestore_id'=>$helpmestore_id,
            //必填
            'sid'=>$sid,
            'firstClassMerchantNo'=>$seafoxpaySet['firstClassMerchantNo'],//商户编号 Y
            'orderNo'=>$orderNo,//商户订单号 Y
            'signName'=>$signName,//子商户签约名 Y
            'showName'=>$showName,//展示名（收银台展示名） Y
            'merchantType'=>$merchantType,//子商户类型 ENTERPRISE 企业商户 INSTITUTION 事业单位商户INSTITUTION 事业单位商户INDIVIDUALBISS  个体工商户 PERSON  个人商户(小微商户)
            'legalPerson'=>$legalPerson,//法人名字
            'legalPersonID'=>$legalPersonID,//法人身份证号
            'orgNum'=>$orgNum,//组织机构代码  1.若是个人商户，统一填写身份证号；2.三证合一，则统一填营业执照号
            'businessLicense'=>$businessLicense,//营业执照号
            'regionCode'=>$district,//区县编码 需填写县级编码（见附件行业编码及地区编码表.zip）
            'address'=>$address,//通讯地址
            'linkman'=>$linkman,//联系人
            'linkPhone'=>$linkPhone,//联系电话
            'email'=>$email,//联系邮箱
            'synChannel'=>$synChannel,//是否同步通道到修改
            'appPayType'=>$appPayType,//支付类型
        ];

        $bodyData['orderNo'] =  'p_'.date('YmdHis').rand(1000,9999).'_'.$sid;

        $interfaceName = 'modifyMerchantInfoV2';
        $bodyData = array_filter($bodyData);
        $res = (new SeafoxPayPart())->bodyDataHandle($bodyData, $interfaceName, $up_url);

        if($res['code'] != '0000'){
            throw new CommonException($res['message']);
        }

        return '修改成功';
    }

    //活动报名资质
    public function activityApplyUrl($params)
    {
        extract($params);

        $helpMeStoreInfo = self::getHelpMeStoreInfo($sid);
        $merchantNo = $helpMeStoreInfo->merchantNo;

        $imgs = $img;

        foreach($imgs as $credentialType => $credentialUrl)
        {
            if(!$credentialUrl || strstr($credentialType, '_methods')){
                continue;
            }
            $credentialUrl = (new CoreImageService())->thumb($this->site_id, $credentialUrl,'small');
            $orderNo = 'p_'.date('YmdHis').rand(1000,9999); 

            $bodyData = array(
                'orderNo'=>$orderNo,
                'merchantNo'=>$merchantNo,
                'credentialUrl'=>$credentialUrl,
                'credentialType'=>$credentialType,//法人身份证正面 FRONT_OF_ID_CARD   法人身份证反面 BACK_OF_ID_CARD
            );
            if($params['img'][$credentialType . '_methods'] == 1)
                $interfaceName = 'uploadImageUrl';
            else
                $interfaceName = 'imageUrlAlteration';
                (new SeafoxPayPart())->bodyDataHandle($bodyData, $interfaceName, "https://payment.dinpay.com/trx/merchantEntry/interface.action");
        }
        return '设置成功';
    }

    //活动报名
    public static function activityApply($params)
    {
        extract($params);

        $helpMeStoreInfo = self::getHelpMeStoreInfo($sid);
        $merchantNo = $helpMeStoreInfo->merchantNo;

        $bodyData = [
            'merchantNo'=>$merchantNo,
            'activityId'=>$activityId,
            'appPayType'=>$appPayType,
            'industryCode'=>$industryCode,
            'remark'=>$remark,
        ];

        if($activityId == 'BLUESEA_1')
            $bodyData['activityScene']=$activityScene;

        $up_url = 'https://payment.dinpay.com/trx/merchantEntry/interface.action';
        $interfaceName = 'activityApply';
        $res = (new SeafoxPayPart())->bodyDataHandle($bodyData, $interfaceName, $up_url);

        if($res['code'] != '0000'){
            throw new CommonException($res['message']);
        }

        return '设置成功';

    }

    //二次修改
    public static function second_activityApply($params)
    {
        extract($params);
        $helpMeStoreInfo = self::getHelpMeStoreInfo($sid);
        $merchantNo = $helpMeStoreInfo->merchantNo;

        $up_url = 'https://payment.dinpay.com/trx/merchantEntry/interface.action';
        $interfaceName = 'activityApplyUpdate';
        $bodyData = array(
            'merchantNo'=>$merchantNo,
            'activityId'=>$activityId,
            'activityModifyInfo' => $remark,
            'industryCode' => $industryCode,
            'remark' => $remark,
        );
        $res = (new SeafoxPayPart())->bodyDataHandle($bodyData,$interfaceName,$up_url);
        if($res['code'] != '0000'){
            throw new CommonException($res['message']);
        }

        return '设置成功';
    }

    //活动报名查询
    public static function activityApplyQuery($params)
    {
        extract($params);
        $helpMeStoreInfo = self::getHelpMeStoreInfo($sid);
        $merchantNo = $helpMeStoreInfo->merchantNo;

        $activityId = $activityId ? $activityId :'SCHOOLCANTEEN_001';

        $bodyData = [
            'merchantNo'=>$merchantNo,
            'activityId'=>$activityId,
        ];

        $up_url = 'https://payment.dinpay.com/trx/merchantEntry/interface.action';
        $interfaceName = 'activityApplyQuery';
        $res = (new SeafoxPayPart())->bodyDataHandle($bodyData, $interfaceName, $up_url);

        if($res['code'] != '0000'){
            throw new CommonException($res['message']);
        }
    }

    //产品手续费收取方式
    public static function modifyProductConfig($params)
    {
        extract($params);
        
        $helpMeStoreInfo = self::getHelpMeStoreInfo($sid);
        $merchantNo = $helpMeStoreInfo->merchantNo;

        $bodyData = [
            'merchantNo'=>trim($merchantNo),
            'type'=>'FeeCollection',
            'productType'=>$productType,
            'value'=>$value,//产品类型 扫码产品:APPPAY
        ];

        $interfaceName = 'modifyProductConfig';
        $res = (new SeafoxPayPart())->bodyDataHandle($bodyData, $interfaceName, "https://payment.dinpay.com/trx/merchantEntry/interface.action");

        if($res['code'] != '0000'){
            throw new CommonException($res['message']);
        }

        return '设置成功';
    }

    public static function getHelpMeStoreInfo($sid)
    {
        $helpmestoreInfo = SeafoxPayMerchantPart::where(['sid' => $sid])->find();
        if(empty($helpmestoreInfo)){
            $data = array(
                'sid'=>$sid,
                'merchantNo'=>'',
                'firstClassMerchantNo'=>'',//商户编号 Y
                'orderNo'=>'',//商户订单号 Y
                'signName'=>'',//子商户签约名 Y
                'showName'=>'',//展示名（收银台展示名） Y
                'merchantType'=>'',//子商户类型 ENTERPRISE 企业商户 INSTITUTION 事业单位商户INSTITUTION 事业单位商户INDIVIDUALBISS  个体工商户 PERSON  个人商户(小微商户)
                'legalPerson'=>'',//法人名字
                'legalPersonID'=>'',//法人身份证号
                'orgNum'=>'',//组织机构代码  1.若是个人商户，统一填写身份证号；2.三证合一，则统一填营业执照号
                'businessLicense'=>'',//营业执照号
                'regionCode'=>'',//区县编码 需填写县级编码（见附件行业编码及地区编码表.zip）
                'address'=>'',//通讯地址
                'linkman'=>'',//联系人
                'linkPhone'=>'',//联系电话
                'email'=>'',//联系邮箱
                'bankCode'=>'',//结算卡联行号
                'accountName'=>'',//开户名
                'accountNo'=>'',//开户账号
                'updateBankCode'=> '',//结算卡联行号
                'updateAccountName'=> '',//开户名
                'updateAccountNo'=>'',//开户账号
                'settleBankType'=>'',//结算卡类型  对公：TOPUBLIC  对私：TOPRIVATE
                'settlementPeriod'=>'',//结算类型
                'settlementMode'=> '',//结算方式
                'merchantCategory'=> '',//经营类别 见附录5.5注：根据附录上传英文值，需和行业编码对应
                'settleMode'=> '',//结算模式 商户合并结算使用，按商户结算，正常结算： MERCHANT 按结算人结算，支持同平台商下，结算卡号一致的结算单合并成一笔出款：MERGE
    
                //必填 默认
                'authorizationFlag'=>'true',//授权使用平台商秘钥 true代表授权，false代表不授权注：平台密钥，通常默认为true
                'needPosFunction'=>'false',//是否需要开通 POS 功能
                'agreeProtocol'=>'true',//是否同意协议
                'idType'=>'IDCARD',//法人证件类型 具体值见附录5.37
    
                //非必填
                'webSite'=>'',//网站网址
                'accessUrl'=>'',//接入地址
                'province'=>'',//子商户所在省份
                'city'=>'',//子商户所在城市
                'bindMobile'=>'',//绑定手机
                'servicePhone'=>'',//客服联系电话
                'settlementRemark'=>'',//结算备注
                'unionPayQrCode'=>'',//银联二维码
                'idCardStartDate'=>'',//法人身份证开始日期 yyyyMMdd
                'idCardEndDate'=>'',//法人身份证结束日期 yyyyMMdd 或者长期有效
                'businessDateStart'=>'',//经营起始日期 yyyyMMdd
                'businessDateLimit'=>'',//经营期限 yyyyMMdd
                'accountIdCard'=>'',//开户人身份证
                'mcc'=>'',//银联 mcc 码
                'callbackUrl'=>'',//回调地址 人工审核后异步回调地址（返回参数为JSON数据）注：人工审核成功或失败会异步通知；自动审核通过，不会通知
                'settlementAuth'=>'',//结算信息鉴权
                'postalAddress'=>'',//注册地址
                'microBizType'=>'',//小微经营类型
                'certType'=>'',//证书类型
                'linkManId'=>'',//联系人身份证号
                'needAuthorize'=>'',//是否需要认证
                'specialSignName'=>'',//是否需要特殊处理商户名称
                'longitude'=>'',//经度
                'latitude'=>'',//纬度
                'electronicAccountNo'=>'',//电子账户
                'settleChangeType'=>'',//结算到账方式
                'settlementIdCardNo'=>'',//结算人身份证号
                'settlementPhoneNo'=>'',//结算人手机号
                'serviceCodes'=>'',//支付宝商
            );
            SeafoxPayMerchantPart::create($data);
            $helpmestoreInfo = SeafoxPayMerchantPart::where(['sid' => $sid])->find();
            // throw new CommonException('请先申请进件');
        }

        return $helpmestoreInfo;
    }

    public static function getFeilv($params)
    {
        extract($params);

        $weixin_feilv = 'none';
        $alipay_feilv = 'none';

        $info = self::getHelpMeStoreInfo($sid, 0);
        if($info) {
            $merchantNo = $info['merchantNo'];
            $weixin_feilv = (new SeafoxPayPart())->oldMethod('WXPAY',$merchantNo, 0);
            $alipay_feilv = (new SeafoxPayPart())->oldMethod('ALIPAY',$merchantNo, 0);

            if($weixin_feilv == false)
                $weixin_feilv = 'none';
            else
                $weixin_feilv = round($weixin_feilv * 100, 2);

            if($alipay_feilv == false)
                $alipay_feilv = 'none';
            else
                $alipay_feilv = round($alipay_feilv * 100, 2);
            
        }
        

        $system_weixin_feilv = $weixin_feilv;
        $system_alipay_feilv = $alipay_feilv;
        $weixin_feilv = $info->weixin_feilv ? round($info->weixin_feilv * 100, 2) : '';
        $alipay_feilv = $info->alipay_feilv ? round($info->alipay_feilv * 100, 2) : '';

        $result = compact("weixin_feilv", "alipay_feilv", "system_weixin_feilv", "system_alipay_feilv");

        return $result;
    }

    public static function setFeilv($params)
    {
        extract($params);

        if(!is_numeric($weixin_feilv) || !is_numeric($alipay_feilv)){
            throw new CommonException('费率设置有误');
        }

        $info = self::getHelpMeStoreInfo($sid, 0);

        $alipay_feilv = $alipay_feilv / 100;
        $weixin_feilv = $weixin_feilv / 100;

        $merchantNo = $info->merchantNo;

        $result = SeafoxPayMerchantPart::field('helpmestore_id,merchantNo,weixin_feilv,alipay_feilv')->where(['merchantNo' => $merchantNo])->find();

        $result->alipay_feilv = $alipay_feilv;
        $result->weixin_feilv = $weixin_feilv;
        $result->save();
        return [];
    }

    //扫描营业执照
    public static function scanBusinessLicense($params)
    {
        extract($params);
        $config = new Config([
            'accessKeyId' => 'LTAINI1rtiFsBUlP',
            'accessKeySecret' => 'O78uaVyag8z7XOIi6XEo8jbcS7z84Q',
        ]);
        // Endpoint 请参考 https://api.aliyun.com/product/ocr-api
        $config->endpoint = "ocr-api.cn-hangzhou.aliyuncs.com";

        $url = $img;

        $client = new Ocrapi($config);
        $recognizeBusinessLicenseRequest = new RecognizeBusinessLicenseRequest([
            "url" => $url
        ]);
        $runtime = new RuntimeOptions([]);
        $runtime->ignoreSSL = true;
        
        try {
            // 复制代码运行请自行打印 API 的返回值
            $result = $client->recognizeBusinessLicenseWithOptions($recognizeBusinessLicenseRequest, $runtime);
            $body = $result->body;
            $data = $body->data;
            $data = json_decode($data, true);
            $basic_data = $data['data'];

            $creditCode = $basic_data['creditCode'];
            $legalPerson = $basic_data['legalPerson'];
            $businessAddress = $basic_data['businessAddress'];

            $addressInfo = (new \app\common\service\map\MapService())->geo($businessAddress);
            $province = $addressInfo['province'];
            $city = $addressInfo['city'];
            $district = $addressInfo['district'];

            $return_data = [
                'creditCode' => $creditCode,
                'legalPerson' => $legalPerson,
                'businessAddress' => $businessAddress,
                'province' => $province,
                'city' => $city,
                'district' => $district,
            ];
        }
        catch (Exception $error) {
            throw new CommonException('错误');
        }

        return $return_data;
    }

    //扫描身份证
    public static function scanIdCard($params)
    {
        extract($params);
        $config = new Config([
            'accessKeyId' => 'LTAI4G3oTMgKYiqGtzQrkCJR',
            'accessKeySecret' => '1AQXM9JeMBJ5v8ZdqYvPhhCKL4wQa9',
        ]);
        $config->endpoint = "ocr-api.cn-hangzhou.aliyuncs.com";

        $url = $img;

        $client = new Ocrapi($config);
        $recognizeIdcardRequest = new RecognizeIdcardRequest([
            "url" => $url
        ]);
        $runtime = new RuntimeOptions([]);
        $runtime->ignoreSSL = true;
        
        try {
            // 复制代码运行请自行打印 API 的返回值
            $result = $client->recognizeIdcardWithOptions($recognizeIdcardRequest, $runtime);
            $body = $result->body;
            $data = $body->data;
            $data = json_decode($data, true);
            $basic_data = $data['data'];

            $basic_data = $basic_data['face']['data'];
            $idNumber = $basic_data['idNumber'];

            $return_data = [
                'idNumber' => $idNumber,
            ];
        }
        catch (Exception $error) {
            throw new CommonException('错误');
        }

        return $return_data;
    }

    //扫描身份证 微信小程序
    public static function scanIdCardByMiniProgram($params)
    {
        // extract($params);
        // $wechat = new \app\common\library\Wechat\WechatApp($uniacid);
        // $access_token = $wechat->getAccessToken(true);

        // $img_url = $img;

        // $url = "https://api.weixin.qq.com/cv/ocr/idcard?access_token=".$access_token;
   		
        // $data = ['img_url' => $img_url];
       
        // $ch  = curl_init();
        // curl_setopt($ch, CURLOPT_URL, $url);
        // curl_setopt($ch, CURLOPT_RETURNTRANSFER , true);
        // curl_setopt($ch, CURLOPT_SSL_VERIFYPEER , false);
        // curl_setopt($ch, CURLOPT_SSL_VERIFYHOST , false);
        // curl_setopt($ch, CURLOPT_POST, 1);
        // curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        // $res  = curl_exec($ch);
        // curl_close($ch);
        // $result = json_decode($res,true);

        // $idNumber = $result['id'];
        // $name = $result['name'];

        // $return_data = [
        //     'legalPerson' => $name,
        //     'idNumber' => $idNumber,
        // ];

        // return $return_data;
    }

    //扫描营业执照 微信小程序
    public static function scanBusinessLicenseByMiniProgram($params)
    {
        // extract($params);
        // $wechat = new \app\common\library\Wechat\WechatApp();
        // $access_token = $wechat->getAccessToken(true);

        // $img_url = $img;

        // $url = "https://api.weixin.qq.com/cv/ocr/bizlicense?access_token=".$access_token;
   		
        // $data = ['img_url' => $img_url];
       
        // $ch  = curl_init();
        // curl_setopt($ch, CURLOPT_URL, $url);
        // curl_setopt($ch, CURLOPT_RETURNTRANSFER , true);
        // curl_setopt($ch, CURLOPT_SSL_VERIFYPEER , false);
        // curl_setopt($ch, CURLOPT_SSL_VERIFYHOST , false);
        // curl_setopt($ch, CURLOPT_POST, 1);
        // curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        // $res  = curl_exec($ch);
        // curl_close($ch);
        // $result = json_decode($res,true);

        // if($result['errcode'] == 0) {
        //     $creditCode = $result['reg_num'];
        //     $legalPerson = $result['legal_representative'];
        //     $businessAddress = $result['address'];

        //     $addressInfo = (new \app\common\service\map\MapService())->geo($businessAddress);
        //     $province = $addressInfo['province'];
        //     $city = $addressInfo['city'];
        //     $district = $addressInfo['district'];

        //     $return_data = [
        //         'creditCode' => $creditCode,
        //         'legalPerson' => $legalPerson,
        //         'businessAddress' => $businessAddress,
        //         'province' => $province,
        //         'city' => $city,
        //         'district' => $district,
        //     ];
        // }else {
        //     //扫描失败，用阿里云的接口再试一次
        //     $return_data = self::scanBusinessLicense($params);
        // }

        // return $return_data;
    }

    public function getProductQrcode($params)
    {
        extract($params);
        $config = SeafoxPaySetting::where(['site_id' => $this->site_id])->findOrEmpty()->toArray();
        return [
            'app_product_wechat_qrcode' => (new CoreImageService())->thumb($this->site_id,$config['app_product_wechat_qrcode'],'small') ?: 'http://qny.wdsp666.com/app/1656918379-%E6%8A%A5%E5%A4%87%E4%BA%8C%E7%BB%B4%E7%A0%81.jpg',
            'app_product_alipay_qrcode' => (new CoreImageService())->thumb($this->site_id,$config['app_product_alipay_qrcode'],'small') ?: 'http://qny.wdsp666.com/images/1/2022/10/NOGX1KoIfJ8354w4bjX48k1nwvzGix.jpg',
        ];
    } 

    public function getCashRegisterConfig($params)
    {
        $sid = $params['sid'] ?? '';
        $result = SeafoxPayMerchantCashRegister::where(['sid' => $sid])->findOrEmpty()->toArray();
        if(!$result) {
            SeafoxPayMerchantCashRegister::create(['sid' => $sid]);
            $result = SeafoxPayMerchantCashRegister::where(['sid' => $sid])->findOrEmpty()->toArray();
        }
        return $result;
    }

    public function setCashRegisterConfig($params)
    {
        $sid = $params['sid'] ?? '';
        $mch_id = $params['mch_id'] ?? '';
        $result = SeafoxPayMerchantCashRegister::where(['sid' => $sid])->findOrEmpty()->toArray();
        if(!$result) {
            SeafoxPayMerchantCashRegister::create(['sid' => $sid]);
        }
        SeafoxPayMerchantCashRegister::where(['sid' => $sid])->update(['mch_id' => $mch_id]);
        return $result;
    }

}