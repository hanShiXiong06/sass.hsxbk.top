<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的多应用管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\seafox_pay\app\service\api;

use addon\seafox_pay\app\model\SeafoxPayMerchant;
use addon\seafox_pay\app\model\SeafoxPayMaidanOrder;
use addon\seafox_pay\app\service\core\CoreMaidanOrderService;
use addon\seafox_pay\app\dict\maidan\MaidanOrderDict;
use core\base\BaseApiService;

/**
 * 充值订单服务层
 * Class RechargeOrderService
 * @package app\service\api\order
 */
class MaidanOrderService extends BaseApiService
{
    public function __construct()
    {
        parent::__construct();
        $this->model = new SeafoxPayMaidanOrder();
    }

    public function getinfo(array $data)
    {
        $list = ( new SeafoxPayMerchant() )->field('id,name,logo')
            ->where([[ 'id', '=', $data['merchant_id'] ] ])
            ->find()->toArray();

        return $list;
    }

    public function pay(array $data)
    {
        $data[ 'order_from' ] = $this->channel;
        $data[ 'member_id' ] = $this->member_id;
        $data[ 'site_id' ] = $this->site_id;
        return ( new CoreMaidanOrderService() )->create($data);
    }


    /**
     * 充值订单分页列表
     * @param array $where
     * @return array
     */
    public function getPage(array $where)
    {
//        $field = 'order_id, order_no, order_from, order_type, out_trade_no, order_status, refund_status, member_id, ip, member_message, money, order_discount_money, order_money, create_time, pay_time, close_time, is_delete, is_enable_refund, remark, invoice_id, close_reason';
        $order = 'create_time desc';
        $where[ 'order_type' ] = 'seafox_pay';
        $search_model = $this->model->where([ [ 'member_id', '=', $this->member_id ],[ 'order_status', '=', 10 ], [ 'site_id', '=', $this->site_id ] ])->withSearch([ 'order_status' ], $where)->order($order)->append([ 'order_from_name' ]);
        $list = $this->pageQuery($search_model);
        $order_status = MaidanOrderDict::getStatus();
        //$refund_status = MaidanOrderDict::getRefundStatus();
        foreach ($list[ 'data' ] as $k => $v) {
            $list[ 'data' ][ $k ][ 'order_status_info' ] = $order_status[ $v[ 'order_status' ] ] ?? [];

            $merchant = ( new SeafoxPayMerchant() )->field('id,name,logo')
                ->where([[ 'id', '=', $v['merchant_id'] ] ])
                ->findOrEmpty()->toArray();
            $list[ 'data' ][ $k ][ 'mer_name' ] = $merchant['name' ] ?? [];
            // $list['data'][$k]['refund_status_name'] = $refund_status[$v['refund_status']]['name'] ?? '';
        }
        return $list;
    }

    /**
     * 充值订单详情
     * @param int $order_id
     * @return array
     */
    public function getDetail(int $order_id)
    {

//        $detail = $this->model->where([ [ 'order_type', '=', 'seafox_pay' ], [ 'member_id', '=', $this->member_id ], [ 'site_id', '=', $this->site_id ], [ 'order_id', '=', $order_id ] ])->field($field)->with([ 'item' => function($query) {
//            $query->field('order_item_id, order_id, member_id, item_id, item_type, item_name, item_image, price, num, item_money, is_refund, refund_no, refund_status, create_time');
//        } ])->append([ 'order_from_name' ])->findOrEmpty()->toArray();
//        if (!empty($detail)) {
//            $detail[ 'order_status_info' ] = MaidanOrderDict::getStatus($detail[ 'order_status' ]) ?? [];
//        }
//        return $detail;
    }

    /**
     * 充值订单状态
     * @return array|array[]|string
     */
    public function getStatus()
    {
        return MaidanOrderDict::getStatus();
    }
}
