<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的saas管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\seafox_pay\app\service\core;
use addon\seafox_pay\app\model\SeafoxPayMerchantPart;
use addon\seafox_pay\app\model\SeafoxPaySetting;
use core\base\BaseAdminService;

/**
 * 海狐聚合支付商户进件服务类
 * Class AgreementService
 * @package app\service\admin\sys
 */
class SeafoxPayPart extends BaseAdminService
{

    protected $key = "";  //扫码产品的签名密钥

    protected $config = "";  //海狐聚合支付配置信息

    protected $delimiter;

    const SEAFOXPAY_UPLOAD_URL = 'https://payment.dinpay.com/trx/merchantEntry/upload.action';

    public function __construct()
    {
        parent::__construct();
        $this->model = new SeafoxPayMerchantPart();

        //分割符
        $this->delimiter = uniqid();
        $this->config = SeafoxPaySetting::where(['site_id' => $this->site_id])->findOrEmpty()->toArray();
        $this->key = $this->config['public_encryption'];
    }

    public function encrypt($data)
    {
        $encData = openssl_encrypt($data, 'DES-EDE3', $this->key, OPENSSL_RAW_DATA);
        $encData = base64_encode($encData);
        return $encData;
    }

    public function decrypt($str)
    {
        $str = base64_decode($str);
        $decData = openssl_decrypt($str, 'DES-EDE3', $this->key, OPENSSL_RAW_DATA);
        $decData = json_decode($decData, true);
        return $decData;
    }

    public function curl_request($url, $https = true, $method = 'get', $data = null)
    {
        //1.初识化curl
        $ch = curl_init($url);
        //2.根据实际请求需求进行参数封装
        //返回数据不直接输出
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        //如果是https请求
        if ($https === true) {
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        }
        //如果是post请求
        if ($method === 'post') {
            //开启发送post请求选项
            curl_setopt($ch, CURLOPT_POST, true);
            //发送post的数据
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        }
        //3.发送请求
        $result = curl_exec($ch);
        //4.返回返回值，关闭连接
        curl_close($ch);
        return $result;
    }

    //文件上传
    public function uploadFile($param)
    {
        $post_data = $this->buildData($param);
        $url = self::SEAFOXPAY_UPLOAD_URL;
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $post_data);
        curl_setopt($curl, CURLOPT_HTTPHEADER, [
            "Content-Type: multipart/form-data; boundary=" . $this->delimiter,
            "Content-Length: " . strlen($post_data)
        ]);
        $response = curl_exec($curl);
        curl_close($curl);
        return $response;
    }
    
    public function bodyDataHandle($bodyData, $interfaceName , $url = '',  $file = array())
    {
        $helibaoSet = $this->config;
        $firstClassMerchantNo = $helibaoSet['firstClassMerchantNo'];
        $key = $helibaoSet['public_autograph']; //海狐聚合支付公共产品签名密钥

        $bodyjson = json_encode($bodyData, JSON_UNESCAPED_UNICODE);
        $body = $this->encrypt($bodyjson);
        $sign = md5($body . '&' . $firstClassMerchantNo . '&' . $key);

        $data = array(
            'interfaceName' => $interfaceName,//产品开通接口
            'body' => $body,
            'sign' => $sign,
            'merchantNo' => $firstClassMerchantNo,
        );

        if ($file) {
            $data['file'] = $file;
            $res = $this->uploadFile($data);
        } else {
            $res = $this->curl_request($url, true, 'post', $data);
        }

        $res = json_decode($res, true);

        return $res;
    }

    public function uploadImageUrl($data ,$url)
    {
        $helibaoSet = $this->config;
        $firstClassMerchantNo = $helibaoSet['firstClassMerchantNo'];
        $key = $helibaoSet['public_autograph']; //海狐聚合支付公共产品签名密钥
        $bodyData = array(
            'orderNo' => $data['orderNo'],
            'merchantNo' => $data['merchantNo'],
            'credentialType' => $data['credentialType'],//法人身份证正面 FRONT_OF_ID_CARD   法人身份证反面 BACK_OF_ID_CARD
        );

        $bodyjson = json_encode($bodyData);
        $body = $this->encrypt($bodyjson);
        $sign = md5($body . '&' . $firstClassMerchantNo . '&' . $key);
        $data = array(
            'interfaceName' => 'imageUrlQuery',//产品开通接口
            'body' => $body,
            'sign' => $sign,
            'merchantNo' => $firstClassMerchantNo,
        );
        $res = $this->curl_request($url, true, 'post', $data);
        $res = json_decode($res, true);
        return $res;
    }

    public function oldMethod($appPayType,$customer_number)
    {
        // //查询费率
        $helibaoSet = $this->config;
        $bodyData = array(
            'productType' => 'APPPAY',//产品类型 扫码产品:APPPAY
            'firstClassMerchantNo' => $helibaoSet['firstClassMerchantNo'],//平台商编号
            'merchantNo' => $customer_number,//子商户编号
            'appPayType' => $appPayType,//客户端类型  WXPAY微信 ALIPAY 支付宝
            'payType' => 'APPLET',//支付类型 SWIPE  刷卡SCAN  扫码WAP   WAPPUBLIC   公众号支付  APPLET   小程序
            'appFeeMode' => 'DEFAULT', //DEFAULT 默认  RANGE 分段
        );
        
        
        $interfaceName = 'productQuery'; //4.4.1 扫码产品查询
        $url = 'https://payment.dinpay.com/trx/merchantEntry/interface.action';
        $res = self::bodyDataHandle($bodyData, $interfaceName, $url);
        if ($res['code'] != '0000') {
            return false;
        }
        $result = $this->decrypt($res['data']);
        $feilv_d = empty($result['value'] / 100) ? 0 : $result['value'] / 100;

        //查询分段费率
        $bodyData = array(
            'productType' => 'APPPAY',//产品类型 扫码产品:APPPAY
            'firstClassMerchantNo' => $helibaoSet['firstClassMerchantNo'],//平台商编号
            'merchantNo' => $customer_number,//子商户编号
            'appPayType' => $appPayType,//客户端类型  WXPAY微信 ALIPAY 支付宝
            'payType' => 'APPLET',//支付类型 SWIPE  刷卡SCAN  扫码WAP   WAPPUBLIC   公众号支付  APPLET   小程序
            'appFeeMode' => 'RANGE', //DEFAULT 默认  RANGE 分段
        );

        $interfaceName = 'productQuery'; //4.4.1 扫码产品查询
        $res = $this->bodyDataHandle($bodyData, $interfaceName, $url);
        if ($res['code'] != '0000') {
            return false;
        }
        $result = $this->decrypt($res['data']);
        $feilv_r = empty($result['feeRanges'][0]['fee']) ? 0 : $result['feeRanges'][0]['fee'] / 100;
        
        $feilv = min(array($feilv_d, $feilv_r));

        return $feilv;
    }
    
    private function buildData($param)
    {
        $data = '';
        $eol = "\r\n";
        $upload = $param['file'];
        unset($param['file']);

        foreach ($param as $name => $content) {
            $data .= "--" . $this->delimiter . "\r\n"
                . 'Content-Disposition: form-data; name="' . $name . "\"\r\n\r\n"
                . $content . "\r\n";
        }
        if (is_array($upload)) {
            // 拼接文件流
            foreach ($upload as $fname => $fcontent) {

                $data .= "--" . $this->delimiter . $eol
                    . 'Content-Disposition: form-data; name=' . $fname . '; filename=""' . "\r\n"
                    . 'Content-Type:application/octet-stream' . "\r\n\r\n";

                $data .= $fcontent . "\r\n";

            }
            $data .= "--" . $this->delimiter . "--\r\n";
        } else {

            $data .= "--" . $this->delimiter . $eol
                . 'Content-Disposition: form-data; name="file"; filename=""' . "\r\n"
                . 'Content-Type:application/octet-stream' . "\r\n\r\n";

            $data .= $upload . "\r\n";
            $data .= "--" . $this->delimiter . "--\r\n";
        }
        return $data;
    }
    
    

}