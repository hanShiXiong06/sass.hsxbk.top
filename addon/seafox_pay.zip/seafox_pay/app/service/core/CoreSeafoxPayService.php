<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的saas管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\seafox_pay\app\service\core;

use addon\seafox_pay\app\model\SeafoxPaySetting;
use app\model\sys\SysConfig;
use core\exception\CommonException;
use core\base\BaseCoreService;
use app\model\pay\Pay;
use app\service\core\pay\CorePayService;
use addon\seafox_pay\app\model\SeafoxPayMaidanOrder;
use addon\seafox_pay\app\model\SeafoxPayMerchant;

/**
 * 海狐聚合支付服务层
 * Class CorePayEventService
 * @package app\service\core\pay
 */
class CoreSeafoxPayService extends BaseCoreService
{

    private $site_id;//站点id
    private $key;// 海狐扫码产品加签密钥
    private $notify_url;

    public function __construct($type ,$params)
    {
        parent::__construct();
        $this->site_id = $params['site_id'];
        $this->notify_url = $params['notify_url'];
        $setting = SeafoxPaySetting::where(['site_id' => $params['site_id']])->findOrEmpty()->toArray();
        if(empty($setting['scancode_autograph'])){
            throw new CommonException('海狐聚合支付加签未设置');
        }
        $this->key =  $setting['scancode_autograph'];
    }

    /**
     * 海狐聚合支付接口
     * key 加密密钥
     * sid  商户自定义的门店编码
     * out_trade_no 商户系统内部订单号，要求50字符以内，同一商户号下订单号唯一
     * customer_number 帮呗分配的商户号
     * appid 如果是小程序支付时填小程序appid
     * openid 小程序openid
     * money  订单金额
     * appType  WXPAY 微信小程序支付  ALIPAY 支付宝支付
     * body 商品名称
     */
    public function pay(array $params = array())
    {
        $customer_number = ''; //海狐聚合支付商户号
        $pay = Pay::where(['site_id' => $this->site_id,'out_trade_no'=>$params['out_trade_no']])->findOrEmpty()->toArray();
        if($pay['trade_type']=='seafox_pay_maidan'){

            $order = SeafoxPayMaidanOrder::where(['site_id' => $this->site_id,'order_id'=>$pay['trade_id']])->findOrEmpty()->toArray();

            $merchant = SeafoxPayMerchant::where(['site_id' => $this->site_id,'id'=>$order['merchant_id']])->findOrEmpty()->toArray();
            $customer_number = $merchant['mch_id'];
        }


        if($params['channel'] == 'weapp'){
            $appType = 'WXPAY';
        }else{
            $appType = 'ALIPAY';
        }
        $config = SysConfig::where(['site_id' => $this->site_id ,'config_key' =>$params['channel']])->findOrEmpty()->toArray();
        if($config && $config['value']['app_id']){
            $app_id = $config['value']['app_id'];
        }

        if(!$app_id){
            throw new CommonException('微信小程序或支付宝APPID未配置');
        }
        if(!$this->key){
            throw new CommonException('海狐聚合支付扫码加签密钥未设置');
        }
        if(!$customer_number){
            throw new CommonException('海狐聚合支付商户号不能为空');
        }

        $pay = Pay::where(['out_trade_no' => $params['out_trade_no']])->findOrEmpty()->toArray();
        $trade_id = $pay['trade_id'];
        $trade_type = $pay['trade_type'];

        $package = array();
        $package['P1_bizType'] = 'AppPayApplet';// 交易类型公众号为 AppPayPublic,小程序为 AppPayApplet
        $package['P2_orderId'] = $params['out_trade_no'];//商户系统内部订单号，要求50字符以内，同一商户号下订单号唯一
        $package['P3_customerNumber'] = $customer_number;//帮呗分配的商户号
        $package['P4_payType'] = 'APPLET'; //PUBLIC:公众号支付APPLET:小程序
        $package['P5_appid'] = $app_id; //微信支付分配的公众账号ID,如果是小程序支付时填小程序appid
        $package['P6_deviceInfo'] = ''; //可以为终端设备号(门店号或收银设备ID)，PC网页或公众号内支付可以传"WEB"
        $package['P7_isRaw'] = 1; //是否原生态 1：是; 0：否 不传默认是1
        $package['P8_openid'] = $params['openid']; //微信用户关注商家公众号的 openidopenid如何获取,可参考6.2注意事项OpenID获取;当P7_isRaw=0微信公众号非原生态时openid上送1即可
        $package['P9_orderAmount'] = $params['money']; //订单金额
        $package['P10_currency'] = 'CNY'; //币种类型 人民币:CNY
        $package['P11_appType'] = $appType; ///客户端类型 WXPAY:微信通知回调地址
        $package['P12_notifyUrl'] = $this->notify_url;//通知回调地址
        $package['P13_successToUrl'] = ''; //页面跳转地址 支付完成后，展示支付结果的页面地址;1,为原生态时该地址请忽略,需要商户自己在js页面控制跳转;2,当P7_isRaw=0微信公众号非原生态时支付完会跳转到该地址
        $package['P14_orderIp'] = '127.0.0.1';
        $package['P15_goodsName'] = $params['body'];//商品名称
        $package['P16_goodsDetail'] = '';
        $package['P17_limitCreditPay'] = '0';//值为 1，禁用信用卡；值为 0 不限,不传以平台为准
        $package['P18_desc'] = json_encode(array('split_type' => ''));

        $valstr = '&' . implode('&', $package);
        $package['sign'] = md5($valstr . '&' . $this->key);

        $url = "https://payment.dinpay.com/trx/app/interface.action";

        $response = $this->curl_request($url, true, 'post', $package);
        $response = json_decode($response, true);

        if ($response['rt2_retCode'] != '0000') {
            throw new CommonException($response['rt3_retMsg']);
        }
        $rt10_payInfo = json_decode($response['rt10_payInfo'], true);
        $package_data = explode('=',$rt10_payInfo['package']);

        $package_key = $package_data[0] ?? 'prepay_id';
        $package_value = $package_data[1] ?? '';

        if($package['P11_appType'] == 'WXPAY'){
            $data = array(
                'appId' => $rt10_payInfo['appId'],
                'timeStamp' => $rt10_payInfo['timeStamp'], 
                'nonceStr' => $rt10_payInfo['nonceStr'], 
                'signType' => $rt10_payInfo['signType'],
                'paySign' => $rt10_payInfo['paySign'],
                'trade_id' => $trade_id,
                'trade_type' => $trade_type,
                'package_key' => $package_key,
                'package_value' => $package_value
            );
        }

        if($package['P11_appType'] == 'ALIPAY'){
            $data = array(
                'tradeNO' => $rt10_payInfo['tradeNO'],
                'trade_id' => $trade_id,
                'trade_type' => $trade_type,
            );
        }
        return ['url' => '/addon/seafox_pay/pages/pay/index', 'param' => $data];
    }


    /**
     * 海狐聚合支付回调接口
     * $action 
     * $callback
     * $params
     */
    public function notify(string $action, callable $callback)
    {
       //$callback_result = $callback('20240731462676539568128', ['status' => 'SUCCESS']);
        $post = input(''); ;

        if($action == 'pay'){

            $out_trade_no = $_POST['rt2_orderId'];
            $status = 'SUCCESS';
            $rt4_status = $_POST['rt4_status'];

            if($rt4_status == 'CLOSE'){
                $status = 'CLOSED';
            }
            // 官方退款状态 INIT:已接收DOING:处理中SUCCESS:成功 FAIL:失败CLOSE:关闭 CANCEL:撤销  框架支付状态 SUCCESS CLOSED NOTPAY

            $callback_result = $callback($out_trade_no, ['status' => $status]);
            if($callback_result){
                exit('success');
            }

            exit('fail');
        }
        if($action == 'refund'){
            $out_trade_no = $_POST['rt2_orderId'];
            $status = 'success';
            $rt5_status = $_POST['rt5_status'];
            if($rt5_status == 'DOING'){
                $status = 'dealing';
            }
            if($rt5_status == 'FAIL'){
                $status = 'fail';
            }
            //官方退款状态 INIT:已接收 DOING:处理中 SUCCESS:成功 FAIL:失败 CLOSE:关闭   框架退款状态 success dealing fail
            $callback_result = $callback($out_trade_no, ['status' => $status]);
            if($callback_result){
                exit('success');
            }
            exit('fail');
        }
    }


    public function addlog($post)
    {
    	$fp=fopen(__DIR__."/log/".date("Y-m-d").".txt","a+");
    	fwrite($fp,'==========post========='.date("Y-m-d H:i:s").'=================='."\r\n");
    	fwrite($fp,'==========首次======================'."\r\n");
    	fwrite($fp,'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']."\r\n");
    	fwrite($fp,var_export($post,true)."\r\n");
    	fclose($fp);
    }
    /**
     * 海狐聚合支付订单退款接口
     * $params
     * key 加密密钥
     * out_trade_no 商户系统内部订单号，要求50字符以内，同一商户号下订单号唯一
     * customer_number 帮呗分配的商户号
     * refund_no 商户退款流水号
     * money  退款金额
     */
    public function refund(array $params = array())
    {
        $customer_number = ''; //海狐聚合支付商户号
        $package = array();
        $package['P1_bizType'] = 'AppPayRefund';// 交易类型公众号为 AppPayClose
        $package['P2_orderId'] = $params['out_trade_no'];//商户系统内部订单号，要求50字符以内，同一商户号下订单号唯一
        $package['P3_customerNumber'] = $customer_number;
        $package['P4_refundOrderId'] = $params['refund_no'];
        $package['P5_amount'] = $params['money'];
        $package['P6_callbackUrl'] = $this->notify_url;
        $valstr = '&' . implode('&', $package);

        $package['sign'] = md5($valstr . '&' . $this->key);
        $package['signatureType'] = 'SM3WITHSM2';
        $url = "https://payment.dinpay.com/trx/app/interface.action";

        $response = $this->curl_request($url, true, 'post', $package);
        $response = json_decode($response, true);
        if ($response['rt2_retCode'] != '0000') {
            return false;
        }
        return true;
    }

    /**
     * 海狐聚合支付订单关闭接口
     * $params
     * key 加密密钥
     * out_trade_no 户系统内部订单号，要求50字符以内，同一商户号下订单号唯一
     * customer_number 帮呗分配的商户号
     */
    public function close(string $out_trade_no = '')
    {
        $customer_number = ''; //海狐聚合支付商户号
        $package = array();
        $package['P1_bizType'] = 'AppPayClose';// 交易类型公众号为 AppPayClose
        $package['P2_orderId'] = $out_trade_no;//商户系统内部订单号，要求50字符以内，同一商户号下订单号唯一
        $package['P3_customerNumber'] = $customer_number;
       
        $valstr = '&' . implode('&', $package);

        $package['sign'] = md5($valstr . '&' . $this->key);
        $package['signatureType'] = 'SM3WITHSM2';
        $url = "https://payment.dinpay.com/trx/app/interface.action";

        $response = $this->curl_request($url, true, 'post', $package);
        $response = json_decode($response, true);
        if ($response['rt2_retCode'] != '0000') {
            return false;
        }
        return true;
    }

    /**
     * 海狐聚合支付获取订单信息接口
     * $params
     * key 加密密钥
     * out_trade_no 户系统内部订单号，要求50字符以内，同一商户号下订单号唯一
     * customer_number 帮呗分配的商户号
     */
    public function getOrder(array $params = array())
    {
        $customer_number = ''; //海狐聚合支付商户号
        $package = array();
        $package['P1_bizType'] = 'AppPayQuery';// 交易类型公众号为 AppPayClose
        $package['P2_orderId'] = $params['out_trade_no'];//商户系统内部订单号，要求50字符以内，同一商户号下订单号唯一
        $package['P3_customerNumber'] = $customer_number;
       
        $valstr = '&' . implode('&', $package);

        $package['sign'] = md5($valstr . '&' . $this->key);
        $package['signatureType'] = 'SM3WITHSM2';
        $url = "https://payment.dinpay.com/trx/app/interface.action";

        $response = $this->curl_request($url, true, 'post', $package);
        $response = json_decode($response, true);
        $orderStatus = $response['rt7_orderStatus'];  // 官方支付状态 INIT：已接收 DOING：处理中 SUCCESS：成功 FAIL：失败 CLOSE：关闭 CANCEL:撤销  框架支付状态 SUCCESS CLOSED NOTPAY
        
        if ($response['rt2_retCode'] != '0000') {
            return ['status' => 'fail'];
        }
        if($orderStatus == 'CLOSE'){
            $orderStatus = 'CLOSED';
        }
        return ['status' => $orderStatus];
    }

        /**
     * 海狐聚合支付获取订单信息接口
     * $params
     * key 加密密钥
     * out_trade_no 商户系统内部订单号，要求50字符以内，同一商户号下订单号唯一
     * refund_no  退款订单号
     * customer_number 帮呗分配的商户号
     */
    public function getRefund($out_trade_no, $refund_no)
    {
        $customer_number = ''; //海狐聚合支付商户号
        $package = array();
        $package['P1_bizType'] = 'AppPayRefundQuery';// 交易类型公众号为 AppPayClose
        $package['P2_refundOrderId'] = $refund_no;//商户系统内部订单号，要求50字符以内，同一商户号下订单号唯一
        $package['P3_customerNumber'] = $customer_number;
       
        $valstr = '&' . implode('&', $package);

        $package['sign'] = md5($valstr . '&' . $this->key);
        $package['signatureType'] = 'SM3WITHSM2';
        $url = "https://payment.dinpay.com/trx/app/interface.action";

        $response = $this->curl_request($url, true, 'post', $package);
        $response = json_decode($response, true);
        $orderStatus = $response['rt8_orderStatus'];  //官方退款状态 INIT:已接收 DOING:处理中 SUCCESS:成功 FAIL:失败 CLOSE:关闭   框架退款状态 success dealing fail
        $fail_reason = $response['rt13_desc'] ?? '';
        if ($response['rt2_retCode'] != '0000') {
            return ['status' => 'fail' ,'fail_reason' => $fail_reason];
        }
        $status = 'success';
        if($orderStatus == 'DOING'){
            $status = 'dealing';
        }
        if($orderStatus == 'FAIL'){
            $status = 'fail';
        }
        return ['status' => $status ,'fail_reason' => $fail_reason];
    }

    // public function encrypt($data)
    // {
    //     $encData = openssl_encrypt($data, 'DES-EDE3', $this->key, OPENSSL_RAW_DATA);
    //     $encData = base64_encode($encData);
    //     return $encData;
    // }

    // public function decrypt($str)
    // {
    //     $str = base64_decode($str);
    //     $decData = openssl_decrypt($str, 'DES-EDE3', $this->key, OPENSSL_RAW_DATA);
    //     $decData = json_decode($decData, true);
    //     return $decData;
    // }

    // private function is_weixin()
    // {
    //     if (empty($_SERVER['HTTP_USER_AGENT']) || ((strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') === false)
    //         && (strpos($_SERVER['HTTP_USER_AGENT'], 'Windows Phone') === false)
    //     )) {
    //         return false;
    //     }
    //     return true;
    // }

    public function curl_request($url, $https = true, $method = 'get', $data = null)
    {
        //1.初识化curl
        $ch = curl_init($url);
        //2.根据实际请求需求进行参数封装
        //返回数据不直接输出
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        //如果是https请求
        if ($https === true) {
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        }
        //如果是post请求
        if ($method === 'post') {
            //开启发送post请求选项
            curl_setopt($ch, CURLOPT_POST, true);
            //发送post的数据
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        }
        //3.发送请求
        $result = curl_exec($ch);
        //4.返回返回值，关闭连接
        curl_close($ch);
        return $result;
    }

    
}