<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的多应用管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

use think\facade\Route;

use app\adminapi\middleware\AdminCheckRole;
use app\adminapi\middleware\AdminCheckToken;
use app\adminapi\middleware\AdminLog;

/**
 * 海狐聚合支付插件
 */
Route::group('seafox_pay', function () {

     /***************************************************** hello world ****************************************************/
    Route::get('hello_world', 'addon\seafox_pay\app\adminapi\controller\hello_world\Index@index');

    // 海狐系统设置路由
    Route::get('setting/getConfig', 'addon\seafox_pay\app\adminapi\controller\setting\Index@getConfig');

    Route::post('setting/setConfig', 'addon\seafox_pay\app\adminapi\controller\setting\Index@setConfig');

    // 商户管理路由
    Route::get('merchant/lists', 'addon\seafox_pay\app\adminapi\controller\merchant\Index@lists');

    Route::post('merchant/delete', 'addon\seafox_pay\app\adminapi\controller\merchant\Index@delete');

    Route::post('merchant/add', 'addon\seafox_pay\app\adminapi\controller\merchant\Index@add');

    Route::post('merchant/edit/:id', 'addon\seafox_pay\app\adminapi\controller\merchant\Index@edit');

    Route::get('merchant/detail', 'addon\seafox_pay\app\adminapi\controller\merchant\Index@detail');

    // 商户进件路由
    Route::post('part/parts', 'addon\seafox_pay\app\adminapi\controller\part\Index@parts');

    Route::post('part/imageUrlQuery', 'addon\seafox_pay\app\adminapi\controller\part\Index@imageUrlQuery');

    Route::post('part/productQuery', 'addon\seafox_pay\app\adminapi\controller\part\Index@productQuery');

    Route::post('part/appapplyqueryAll', 'addon\seafox_pay\app\adminapi\controller\part\Index@appapplyqueryAll');

    Route::post('part/wxPublicApplyQuery', 'addon\seafox_pay\app\adminapi\controller\part\Index@wxPublicApplyQuery');

    Route::post('part/aliSubMerchantUpdate', 'addon\seafox_pay\app\adminapi\controller\part\Index@aliSubMerchantUpdate');

    Route::post('part/bindorauth', 'addon\seafox_pay\app\adminapi\controller\part\Index@bindorauth');

    Route::post('part/cardalteration', 'addon\seafox_pay\app\adminapi\controller\part\Index@cardalteration');

    Route::post('part/modifyMerchantInfo', 'addon\seafox_pay\app\adminapi\controller\part\Index@modifyMerchantInfo');

    Route::post('part/activityApplyUrl', 'addon\seafox_pay\app\adminapi\controller\part\Index@activityApplyUrl');


    Route::post('part/activityApply', 'addon\seafox_pay\app\adminapi\controller\part\Index@activityApply');

    Route::post('part/second_activityApply', 'addon\seafox_pay\app\adminapi\controller\part\Index@second_activityApply');

    Route::post('part/activityApplyQuery', 'addon\seafox_pay\app\adminapi\controller\part\Index@activityApplyQuery');

    Route::post('part/modifyProductConfig', 'addon\seafox_pay\app\adminapi\controller\part\Index@modifyProductConfig');

    Route::post('part/info', 'addon\seafox_pay\app\adminapi\controller\part\Index@info');

    Route::post('part/getBaseInfo', 'addon\seafox_pay\app\adminapi\controller\part\Index@getBaseInfo');

    Route::post('part/getFeilv', 'addon\seafox_pay\app\adminapi\controller\part\Index@getFeilv');

    Route::post('part/setFeilv', 'addon\seafox_pay\app\adminapi\controller\part\Index@setFeilv');
    
    Route::post('part/scanBusinessLicense', 'addon\seafox_pay\app\adminapi\controller\part\Index@scanBusinessLicense');

    Route::post('part/scanIdCard', 'addon\seafox_pay\app\adminapi\controller\part\Index@scanIdCard');

    Route::post('part/scanBusinessLicenseByMiniProgram', 'addon\seafox_pay\app\adminapi\controller\part\Index@scanBusinessLicenseByMiniProgram');

    Route::post('part/scanIdCardByMiniProgram', 'addon\seafox_pay\app\adminapi\controller\part\Index@scanIdCardByMiniProgram');

    Route::post('part/getProductQrcode', 'addon\seafox_pay\app\adminapi\controller\part\Index@getProductQrcode');

    Route::post('part/getCashRegisterConfig', 'addon\seafox_pay\app\adminapi\controller\part\Index@getCashRegisterConfig');

    Route::post('part/setCashRegisterConfig', 'addon\seafox_pay\app\adminapi\controller\part\Index@setCashRegisterConfig');



    /***************************************************** 买单 *************************************************/
    //订单列表

    Route::get('maidan/order', 'addon\seafox_pay\app\adminapi\controller\maidan\Order@lists');

    //订单状态
    Route::get('maidan/order/status', 'addon\seafox_pay\app\adminapi\controller\maidan\Order@status');


    Route::post('fenzhang/getset', 'addon\seafox_pay\app\adminapi\controller\fenzhang\Set@getSet');
    Route::post('fenzhang/saveset', 'addon\seafox_pay\app\adminapi\controller\fenzhang\Set@saveSet');
    Route::post('fenzhang/selectmerlist', 'addon\seafox_pay\app\adminapi\controller\fenzhang\Set@selectmerlist');



})->middleware([
    AdminCheckToken::class,
    AdminCheckRole::class,
    AdminLog::class
]);
