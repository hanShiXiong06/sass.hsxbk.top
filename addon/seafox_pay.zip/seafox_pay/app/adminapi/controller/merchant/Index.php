<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的多应用管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\seafox_pay\app\adminapi\controller\merchant;

use core\base\BaseAdminController;
use addon\seafox_pay\app\service\admin\SeafoxPayMerchantService;
use think\Response;

class Index extends BaseAdminController
{

    /**
     * lists 获取海狐聚合支付商户列表
     * @return Response
     */
    public function lists()
    {
        $data = $this->request->params([
            ['page', 1],
            ['limit', 10],
            ['title','']
        ], false);
        $this->validate($data, 'addon\seafox_pay\app\validate\SeafoxPayMerchant.lists');
        $res = (new SeafoxPayMerchantService())->lists($data);
        return success($res);
    }

    /**
     * detail 获取海狐聚合支付商户详情
     * @return Response
     */
    public function detail()
    {
        $data = $this->request->params([
            ['id', 0],
        ], false);
        $this->validate($data, 'addon\seafox_pay\app\validate\SeafoxPayMerchant.detail');
        $res = (new SeafoxPayMerchantService())->detail($data);
        return success($res);
    }

    /**
     * delete 删除商户
     * @return Response
     */
    public function delete()
    {
        $data = $this->request->params([
            ['id', 0],
        ], false);
        $this->validate($data, 'addon\seafox_pay\app\validate\SeafoxPayMerchant.delete');
        (new SeafoxPayMerchantService())->delete($data);
        return success('DELETE_SUCCESS');
    }

    /**
     * add 添加海狐聚合支付商户
     * @return Response
     */
    public function add()
    {
        $data = $this->request->params([
            ['name', ''],
            ['logo', ''],
            ['mch_id', ''],
        ], false);
        $this->validate($data, 'addon\seafox_pay\app\validate\SeafoxPayMerchant.add');
        (new SeafoxPayMerchantService())->add($data);
        return success('ADD_SUCCESS');
    }

    /**
     * add 编辑海狐聚合支付商户
     * @return Response
     */
    public function edit(int $id)
    {
        $data = $this->request->params([
            ['name', ''],
            ['logo', ''],
            ['mch_id', ''],
        ], false);
        $this->validate($data, 'addon\seafox_pay\app\validate\SeafoxPayMerchant.edit');
        (new SeafoxPayMerchantService())->edit($id,$data);
        return success('EDIT_SUCCESS');
    }

}
