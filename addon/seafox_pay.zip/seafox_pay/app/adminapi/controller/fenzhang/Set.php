<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的多应用管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\seafox_pay\app\adminapi\controller\fenzhang;

use core\base\BaseAdminController;
use think\Response;
use addon\seafox_pay\app\service\admin\FenzhangSetService;


class Set extends BaseAdminController
{

    public function getSet()
    {
        $data = $this->request->params([
            [ 'merchant_id', '' ],
        ]);

        return success(( new FenzhangSetService() )->getSet($data));
    }
    public function saveSet()
    {
        $data = $this->request->params([
            [ 'merchant_id', '' ],
            [ 'open', '' ],
            [ 'fenlist', '' ],
        ]);

        return success(( new FenzhangSetService() )->saveSet($data));
    }

    public function selectmerlist()
    {
        $data = $this->request->params([
        ]);
        return success(( new FenzhangSetService() )->selectmerlist($data));
    }
}
