<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的多应用管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\seafox_pay\app\adminapi\controller\part;

use core\base\BaseAdminController;
use addon\seafox_pay\app\service\admin\SeafoxPayMerchantPartService;

class Index extends BaseAdminController
{

    /**
     * 进件控制器
     */
    public function parts()
    {
        $params = request()->post();
        $result = (new SeafoxPayMerchantPartService())->parts($params);
        return success($result);
    }

    /**
     * 资质上传
     */
    public function imageUrlQuery()
    {
        $params = request()->post();
        $result = (new SeafoxPayMerchantPartService())->imageUrlQuery($params);
        return success($result);
    }

    /**
     * 产品开通
     */
    public function productQuery()
    {
        $params = request()->post();
        $result = (new SeafoxPayMerchantPartService())->productQuery($params);
        return success($result);
    }

    /**
     * app报备
     */
    public function appapplyqueryAll()
    {
        $params = request()->post();
        $result = (new SeafoxPayMerchantPartService())->appapplyqueryAll($params);
        return success($result);
    }

    /**
     * 微信进件
     */
    public function wxPublicApplyQuery()
    {
        $params = request()->post();
        $result = (new SeafoxPayMerchantPartService())->wxPublicApplyQuery($params);
        return success($result);
    }

    /**
     * 二级商户修改(支)
     */
    public function aliSubMerchantUpdate()
    {
        $params = request()->post();
        $result = (new SeafoxPayMerchantPartService())->aliSubMerchantUpdate($params);
        return success($result);
    }

    /**
     * 代运营授权绑定
     */
    public function bindorauth()
    {
        $params = request()->post();
        $result = (new SeafoxPayMerchantPartService())->bindorauth($params);
        return success($result);
    }

    /**
     * 结算卡信息变更
     */
    public function cardalteration()
    {
        $params = request()->post();
        $result = (new SeafoxPayMerchantPartService())->cardalteration($params);
        return success($result);
    }

    /**
     * 商户信息修改
     */
    public function modifyMerchantInfo()
    {
        $params = request()->post();
        $result = (new SeafoxPayMerchantPartService())->modifyMerchantInfo($params);
        return success($result);
    }

    /**
     * 活动资质上传
     */
    public function activityApplyUrl()
    {
        $params = request()->post();
        $result = (new SeafoxPayMerchantPartService())->activityApplyUrl($params);
        return success($result);
    }

    /**
     * 活动报名
     */
    public function activityApply()
    {
        $params = request()->post();
        $result = (new SeafoxPayMerchantPartService())->activityApply($params);
        return success($result);
    }

    /**
     * 二次修改
     */
    public function second_activityApply()
    {
        $params = request()->post();
        $result = (new SeafoxPayMerchantPartService())->second_activityApply($params);
        return success($result);
    }

    /**
     * 活动报名查询
     */
    public function activityApplyQuery()
    {
        $params = request()->post();
        $result = (new SeafoxPayMerchantPartService())->activityApplyQuery($params);
        return success($result);
    }

    /**
     * 产品手续费收取方式
     */
    public function modifyProductConfig()
    {
        $params = request()->post();
        $result = (new SeafoxPayMerchantPartService())->modifyProductConfig($params);
        return success($result);
    }


    /**
     * 获取信息
     */
    public function info()
    {
        $params = request()->post();
        $result = (new SeafoxPayMerchantPartService())->getInfoByType($params);
        return success($result);
    }

    /**
     * 获取公共信息
     */
    public function getBaseInfo()
    {
        $result = (new SeafoxPayMerchantPartService())->getBaseInfo();
        return success($result);
    }

    /**
     * 查询费率
     */
    public function getFeilv()
    {
        $params = request()->post();
        $result = (new SeafoxPayMerchantPartService())->getFeilv($params);
        return success($result);
    }

    /**
     * 设置费率
     */
    public function setFeilv()
    {
        $params = request()->post();
        $result = (new SeafoxPayMerchantPartService())->setFeilv($params);
        return success($result);
    }

    /**
     * 扫描营业执照
     */
    public function scanBusinessLicense()
    {
        $params = request()->post();
        $result = (new SeafoxPayMerchantPartService())->scanBusinessLicense($params);
        return success($result);
    }

    /**
     * 扫描身份证
     */
    public function scanIdCard()
    {
        $params = request()->post();
        $result = (new SeafoxPayMerchantPartService())->scanIdCard($params);
        return success($result);
    }

    /**
     * 扫描营业执照、微信小程序
     */
    public function scanBusinessLicenseByMiniProgram()
    {
        $params = request()->post();
        $result = (new SeafoxPayMerchantPartService())->scanBusinessLicenseByMiniProgram($params);
        return success($result);
    }

    /**
     * 扫描身份证、微信小程序
     */
    public function scanIdCardByMiniProgram()
    {
        $params = request()->post();
        $result = (new SeafoxPayMerchantPartService())->scanIdCardByMiniProgram($params);
        return success($result);
    }

    /**
     * 获取产品二维码
     */
    public function getProductQrcode()
    {
        $params = request()->post();
        $result = (new SeafoxPayMerchantPartService())->getProductQrcode($params);
        return success($result);
    }

    /**
     * 获取商户号设置
     */
    public function getCashRegisterConfig()
    {
        $params = request()->post();
        $result = (new SeafoxPayMerchantPartService())->getCashRegisterConfig($params);
        return success($result);
    }

    /**
     * 商户号设置
     */
    public function setCashRegisterConfig()
    {
        $params = request()->post();
        $result = (new SeafoxPayMerchantPartService())->setCashRegisterConfig($params);
        return success($result);
    }
    
}