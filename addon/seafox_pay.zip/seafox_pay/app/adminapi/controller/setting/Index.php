<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的多应用管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\seafox_pay\app\adminapi\controller\setting;

use core\base\BaseAdminController;
use addon\seafox_pay\app\service\admin\SeafoxPaySettingService;
use think\Response;

class Index extends BaseAdminController
{

    /**
     * getConfig 获取海狐聚合支付配置
     * @return Response
     */
    public function getConfig()
    {
        $res = (new SeafoxPaySettingService())->getConfig();
        return success($res);
    }

    /**
     * setConfig 设置海狐聚合支付配置
     * @return Response
     */
    public function setConfig()
    {
        $data = $this->request->params([
            ['firstClassMerchantNo', ''],
            ['public_encryption', ''],
            ['public_autograph', ''],
            ['scancode_encryption', ''],
            ['scancode_autograph', ''],
            ['merchant_privateKey', ''],
            ['merchant_cannelName', ''],
            ['receiptAppIds', ''],
            ['app_product_wechat_qrcode', ''],
            ['app_product_alipay_qrcode', ''],
        ], false);
        $this->validate($data, 'addon\seafox_pay\app\validate\SeafoxPaySetting.setConfig');
        (new SeafoxPaySettingService())->setConfig($data);
        return success('EDIT_SUCCESS');
    }

}
