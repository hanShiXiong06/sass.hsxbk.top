<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的saas管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\seafox_pay\app\validate;

use think\Validate;

/**
 * 海狐聚合支付进件校验
 * Class AdValidate
 * @package app\adminapi\validate\ad
 */
class SeafoxpayMerchantPart extends Validate
{
    protected $rule = [
        // 'firstClassMerchantNo' => 'require',
        'signName' => 'require',
        'showName' => 'require',
        'merchantType'=> 'require', 
        'legalPerson' => 'require',
        'legalPersonID' => 'require',
        'orgNum' => 'require',
        'businessLicense' => 'require',
        'province' => 'require',
        'city' => 'require',
        'area' => 'require',
        'address' => 'require',
        'linkman' => 'require',
        'linkPhone' => 'require',
        'email' => 'require',
        'bankCode' => 'require',
        'accountName' => 'require',
        'accountNo' => 'require',
        'settleBankType' => 'require',
        'settlementPeriod' => 'require',
        'settlementMode' => 'require',
        'merchantCategory' => 'require',
        'settleMode' => 'require',

        'appPayType' => 'require',
        'payType' => 'require',
        'value' => 'require',
        'minFee' => 'number',
        'appFeeMode' => 'require',
        'feePurpose' => 'require',
        'feeRanges' => 'require',

        'subMerchantNo' => 'require',
        'mcc' => 'require',

        'alipayAccount' => 'require',
        'is_update' => 'require',

        'updateBankCode' => 'require',
        'updateAccountName' => 'require',
        'updateAccountNo' => 'require',
        'merchantEntryAlterationType' => 'require',

        'synChannel' => 'require',

        'imgs' => 'require',

        'activityId' => 'require',
        'industryCode' => 'require',

        'productType' => 'require',

        'weixin_feilv' => 'require',
        'alipay_feilv' => 'require',
    ];

    protected $message = [
        // 'sid.require' => 'ID不能为空',
        // 'firstClassMerchantNo.require' => '商户编号不能为空',
        'signName.require' => '签约名不能为空',
        'showName.require' => '展示名不能为空',
        'merchantType.require' => '门店类目标准二级类目不能为空',
        'legalPerson.require' => '法人名字不能为空',
        'legalPersonID.require' => '法人身份证不能为空',
        'orgNum.require' => '组织机构代码不能为空',
        'businessLicense.require' => '营业执照号不能为空',
        'area.require' => '地区不能为空',
        'address.require' => '通讯地址不能为空',
        'linkman.require' => '联系人不能为空',
        'linkPhone.require' => '联系电话不能为空',
        'email.require' => '邮箱不能为空',
        'bankCode.require' => '结算卡号不能为空',
        'accountName.require' => '开户名不能为空',
        'accountNo.require' => '开户账号不能为空',
        'settleBankType.require' => '结算卡类型不能为空',
        'settlementPeriod.require' => '结算类型不能为空',
        'settlementMode.require' => '结算方式不能为空',
        'merchantCategory.require' => '经营类别不能为空',
        'settleMode.require' => '结算模式不能为空',

        'appPayType.require' => '客户类型不能为空',
        'payType.require' => '支付类型不能为空',
        'value.require' => '费率不能为空',
        'minFee.number' => '最低费率金额不能为空',
        'appFeeMode.require' => '费率模式不能为空',
        'feePurpose.require' => '费率类型不能为空',
        'feeRanges.require' => 'feeRanges不能为空',

        'subMerchantNo.require' => '支付宝商户编号不能为空',
        'mcc.require' => '结算卡联行号不能为空',

        'alipayAccount.require' => '商户支付宝账号不能为空',
        'is_update.require' => '请确定类型',

        'synChannel.require' => '是否同步通道到修改不能为空',

        'imgs.require' => '图片不能为空',

        'activityId.require' => '活动标识不能为空',
        'industryCode.require' => '支付宝行业code不能为空',

        'productType.require' => '产品类型不能为空',

        'weixin_feilv' => '请填写微信费率',
        'alipay_feilv'=> '请填写支付宝费率'
    ];

    public function sceneParts()
    {
        $this->only(['firstClassMerchantNo','signName','showName','merchantType','legalPerson','legalPersonID','orgNum','businessLicense','area','address','linkman','linkPhone','email','bankCode','accountName','accountNo','settleBankType','settlementPeriod','settlementMode','merchantCategory','settleMode']);
    }

    public function sceneProductQuery()
    {
        $this->only(['appPayType','payType','value','minFee','appFeeMode','feePurpose','feeRanges']);
    }

    public function sceneAliSubMerchantUpdate()
    {
        $this->only(['subMerchantNo','mcc']);
    }

    public function sceneBindorauth()
    {
        $this->only(['alipayAccount','is_update']);
    }

    public function sceneCardalteration()
    {
        $this->only(['bankCode','accountName','accountNo','updateBankCode','updateAccountName','updateAccountNo','settleBankType','settlementPeriod','settlementMode','settleMode','merchantEntryAlterationType']);
    }

    public function sceneModifyMerchantInfo()
    {
        $this->only(['signName','showName','merchantType','legalPerson','legalPersonID','orgNum','businessLicense','address','linkman','linkPhone','email','synChannel','appPayType']);
    }

    public function sceneActivityApplyUrl()
    {
        $this->only(['imgs']);
    }

    public function sceneActivityApply()
    {
        $this->only(['activityId','appPayType','industryCode']);
    }

    public function sceneActivityApplyQuery()
    {
        $this->only(['activityId']);
    }

    public function sceneModifyProductConfig()
    {
        $this->only(['productType']);
    }

    public function sceneSetFeilv()
    {
        $this->only(['weixin_feilv', 'alipay_feilv']);
    }

}