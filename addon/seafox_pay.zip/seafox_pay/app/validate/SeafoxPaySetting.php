<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的saas管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\seafox_pay\app\validate;

use think\Validate;

/**
 * 海湖聚合支付数据验证
 * Class Agreement
 * @package app\validate\sys
 */
class SeafoxPaySetting extends Validate
{

    protected $rule = [
        'firstClassMerchantNo' => 'require',
        'public_encryption' => 'require',
        'public_autograph' => 'require',
        'scancode_encryption' => 'require',
        'scancode_autograph' => 'require',
        'merchant_privateKey' => 'require',
        'receiptAppIds' => 'require'
    ];

    protected $message = [];

    protected $scene = [
        'setConfig' => ['firstClassMerchantNo', 'public_encryption','public_autograph', 'scancode_encryption','scancode_autograph','merchant_privateKey','receiptAppIds']
    ];

}