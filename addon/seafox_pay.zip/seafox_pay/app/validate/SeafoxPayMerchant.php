<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的saas管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\seafox_pay\app\validate;

use think\Validate;

/**
 * 海湖聚合支付商户数据验证
 * Class Agreement
 * @package app\validate\sys
 */
class SeafoxPayMerchant extends Validate
{

    protected $rule = [
        'page' => 'require',
        'limit' => 'require',
        'name' => 'require',
        'id' => 'require'
    ];

    protected $message = [
        'id.require' => 'ID不能为空',
        'name.require' => '商户名称不能为空'
    ];

    protected $scene = [
        'lists' => ['page','limit'],
        'delete' => ['id'],
        'add' => ['name'],
        'edit' => ['name'],
        'detail' => ['id']
    ];

}