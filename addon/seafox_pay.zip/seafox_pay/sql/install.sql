CREATE TABLE IF NOT EXISTS `{{prefix}}seafoxpay_setting` (
    `id` int unsigned NOT NULL AUTO_INCREMENT,
    `site_id` int(11) NOT NULL DEFAULT '0' COMMENT '站点id',
    `firstClassMerchantNo` varchar(255) NOT NULL DEFAULT '' COMMENT '商户编号',
    `public_encryption` varchar(255) NOT NULL DEFAULT '' COMMENT '公共产品的加密key',
    `public_autograph` varchar(255) NOT NULL DEFAULT '' COMMENT '公共产品的签名key',
    `scancode_encryption` varchar(255) NOT NULL DEFAULT '' COMMENT '扫码产品的加密key',
    `scancode_autograph` varchar(255) NOT NULL DEFAULT '' COMMENT '扫码产品的签名key',
    `merchant_privateKey` varchar(255) NOT NULL DEFAULT '' COMMENT '商户私钥',
    `merchant_cannelName` varchar(255) NOT NULL DEFAULT '' COMMENT '渠道名',
    `receiptAppIds` varchar(255) NOT NULL DEFAULT '' COMMENT '小程序APPID',
    `app_product_wechat_qrcode` varchar(255) NOT NULL DEFAULT '' COMMENT 'app报备微信图片',
    `app_product_alipay_qrcode` varchar(255) NOT NULL DEFAULT '' COMMENT 'app报备支付宝图片',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='海狐聚合支付插件配置';

-- ----------------------------
-- Table structure for {{prefix}}seafoxpay_maidan_order
-- ----------------------------
DROP TABLE IF EXISTS `{{prefix}}seafoxpay_maidan_order`;
CREATE TABLE `{{prefix}}seafoxpay_maidan_order`  (
                                               `order_id` int(11) NOT NULL AUTO_INCREMENT,
                                               `site_id` int(11) NULL DEFAULT 0 COMMENT '站点id',
                                               `merchant_id` int(11) NULL DEFAULT NULL COMMENT '商户id',
                                               `order_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '订单编号',
                                               `order_from` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '订单来源',
                                               `order_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '订单类型',
                                               `out_trade_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '支付流水号',
                                               `order_status` int(11) NULL DEFAULT 0 COMMENT '订单状态',
                                               `refund_status` int(11) NULL DEFAULT 0 COMMENT '退款状态',
                                               `member_id` int(11) NULL DEFAULT 0 COMMENT '会员id',
                                               `ip` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '会员ip',
                                               `member_message` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '会员留言信息',
                                               `order_item_money` decimal(10, 2) NULL DEFAULT 0.00 COMMENT '订单项目金额',
                                               `order_discount_money` decimal(10, 2) NULL DEFAULT 0.00 COMMENT '订单优惠金额',
                                               `order_money` decimal(10, 2) NULL DEFAULT 0.00 COMMENT '订单金额',
                                               `create_time` int(11) NULL DEFAULT 0 COMMENT '创建时间',
                                               `pay_time` int(11) NULL DEFAULT 0 COMMENT '订单支付时间',
                                               `close_time` int(11) NULL DEFAULT 0 COMMENT '订单关闭时间',
                                               `is_delete` int(11) NULL DEFAULT 0 COMMENT '是否删除(针对后台)',
                                               `is_enable_refund` int(11) NULL DEFAULT 0 COMMENT '是否允许退款',
                                               `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '商家留言',
                                               `invoice_id` int(11) NULL DEFAULT 0 COMMENT '发票id，0表示不开发票',
                                               `close_reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '关闭原因',
                                               PRIMARY KEY (`order_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 49 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '订单表' ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;

DROP TABLE IF EXISTS `{{prefix}}seafoxpay_merchant`;
CREATE TABLE `{{prefix}}sseafoxpay_merchant`  (
                                           `id` int(11) NOT NULL AUTO_INCREMENT,
                                           `site_id` int(11) NULL DEFAULT NULL,
                                           `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '商户名称',
                                           `logo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '商户LOGO',
                                           `mch_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '商户号',
                                           `addtime` int(10) NOT NULL COMMENT '添加时间',
                                           PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '海狐聚合支付商户' ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;



CREATE TABLE IF NOT EXISTS `{{prefix}}seafoxpay_merchant_comingpart` (
  `helpmestore_id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) NOT NULL DEFAULT '0'COMMENT '商户id',
  `firstClassMerchantNo` varchar(16) NOT NULL COMMENT '平台商商编',
  `merchantNo` varchar(100) DEFAULT NULL COMMENT '子商户编号',
  `orderNo` varchar(50) NOT NULL DEFAULT 'member' COMMENT '商户订单号',
  `signName` varchar(150) NOT NULL COMMENT '子商户签约名',
  `showName` varchar(100) NOT NULL COMMENT '展示名',
  `webSite` varchar(150) DEFAULT NULL COMMENT '网站网址',
  `accessUrl` varchar(150) DEFAULT NULL COMMENT '接入地址',
  `merchantType` varchar(20) NOT NULL COMMENT '子商户类型',
  `legalPerson` varchar(20) NOT NULL COMMENT '法人名字',
  `legalPersonID` varchar(30) NOT NULL COMMENT '法人身份证号',
  `orgNum` varchar(30) NOT NULL COMMENT '组织机构代码',
  `businessLicense` varchar(30) NOT NULL COMMENT '营业执照号',
  `province` varchar(15) DEFAULT NULL COMMENT '子商户所在省份',
  `city` varchar(15) DEFAULT NULL COMMENT '子商户所在城市',
  `regionCode` varbinary(8) NOT NULL COMMENT '区县编码',
  `address` varchar(150) NOT NULL COMMENT '通讯地址',
  `linkman` varchar(15) NOT NULL COMMENT '联系人',
  `linkPhone` varchar(20) NOT NULL COMMENT '联系电话',
  `email` varchar(50) NOT NULL COMMENT '联系邮箱',
  `bindMobile` varchar(25) DEFAULT NULL COMMENT '绑定手机',
  `servicePhone` varchar(20) DEFAULT NULL COMMENT '客服联系电话',
  `bankCode` varchar(13) NOT NULL COMMENT '结算卡联行号',
  `accountName` varchar(50) NOT NULL COMMENT '开户名',
  `accountNo` varchar(30) NOT NULL COMMENT '开户账',
  `settleBankType` varchar(20) NOT NULL COMMENT '结算卡类型',
  `settlementPeriod` varchar(20) NOT NULL COMMENT '结算类型',
  `settlementMode` varchar(20) NOT NULL COMMENT '结算方式',
  `settlementRemark` varchar(20) DEFAULT NULL COMMENT '结算备注',
  `merchantCategory` varchar(35) NOT NULL COMMENT '经营类别',
  `industryTypeCode` varchar(10) DEFAULT NULL COMMENT '行业类型编码',
  `authorizationFlag` varchar(10) NOT NULL COMMENT '授权使用平台商秘钥',
  `unionPayQrCode` varchar(100) DEFAULT NULL COMMENT '银联二维码',
  `needPosFunction` float(10,0) NOT NULL DEFAULT '0' COMMENT '是否需要开通 POS 功能',
  `settleMode` varchar(60) NOT NULL COMMENT '结算模式',
  `idType` varchar(20) NOT NULL COMMENT '法人证件类型',
  `agreeProtocol` float(10,0) NOT NULL DEFAULT '0' COMMENT '是否同意协议',
  `weixin_feilv` decimal(10,5) DEFAULT NULL COMMENT '微信费率',
  `alipay_feilv` decimal(10,5) DEFAULT NULL COMMENT '支付宝费率',
  PRIMARY KEY (`helpmestore_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='海狐聚合支付商户进件信息';

CREATE TABLE IF NOT EXISTS `{{prefix}}seafoxpay_merchant_cash_register` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) NOT NULL DEFAULT '0' COMMENT '门店id',
  `mch_id` varchar(32) NOT NULL DEFAULT '' COMMENT '商户号',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='海狐聚合支付商户号配置';