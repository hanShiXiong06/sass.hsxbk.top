DROP TABLE  IF EXISTS `{{prefix}}seafoxpay_setting`;
DROP TABLE  IF EXISTS `{{prefix}}seafoxpay_merchant`;
DROP TABLE  IF EXISTS `{{prefix}}seafoxpay_merchant_comingpart`;
DROP TABLE  IF EXISTS `{{prefix}}seafoxpay_merchant_cash_register`;
