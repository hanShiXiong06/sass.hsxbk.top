import type WaterFall from './water-fall.vue'

export type TnWaterFallInstance = InstanceType<typeof WaterFall>
