import type ActionSheet from './action-sheet.vue'

export type TnActionSheetInstance = InstanceType<typeof ActionSheet>
