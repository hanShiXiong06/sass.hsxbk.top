import type DateTimePicker from './date-time-picker.vue'

export type TnDateTimePickerInstance = InstanceType<typeof DateTimePicker>
