// date-time-picker内部统一时间格式
export const innerDefaultDateTimeFormat = 'YYYY/MM/DD HH:mm:ss'
