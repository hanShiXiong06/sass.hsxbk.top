import type Empty from './empty.vue'

export type TnEmptyInstance = InstanceType<typeof Empty>
