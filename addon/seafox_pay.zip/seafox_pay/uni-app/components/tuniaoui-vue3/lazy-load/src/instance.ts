import type LazyLoad from './lazy-load.vue'

export type TnLazyLoadInstance = InstanceType<typeof LazyLoad>
