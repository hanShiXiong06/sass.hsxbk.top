export type LazyLoadStatus = 'waiting' | 'loading' | 'loaded' | 'error'
