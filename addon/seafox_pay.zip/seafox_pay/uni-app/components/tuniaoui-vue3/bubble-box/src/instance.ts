import type BubbleBox from './bubble-box.vue'

export type TnBubbleBoxInstance = InstanceType<typeof BubbleBox>
