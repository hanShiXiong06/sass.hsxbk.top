import type Tag from './tag.vue'

export type TnTagInstance = InstanceType<typeof Tag>
