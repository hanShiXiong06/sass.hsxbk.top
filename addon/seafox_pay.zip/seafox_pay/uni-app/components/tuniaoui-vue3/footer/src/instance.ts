import type Footer from './footer.vue'

export type TnFooterInstance = InstanceType<typeof Footer>
