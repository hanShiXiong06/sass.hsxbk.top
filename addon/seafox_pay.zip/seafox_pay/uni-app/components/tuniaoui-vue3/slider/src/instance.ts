import type Slider from './slider.vue'

export type TnSliderInstance = InstanceType<typeof Slider>
