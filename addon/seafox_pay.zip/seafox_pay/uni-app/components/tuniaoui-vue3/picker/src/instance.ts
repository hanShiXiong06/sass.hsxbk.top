import type Picker from './picker.vue'

export type TnPickerInstance = InstanceType<typeof Picker>
