import type Title from './title.vue'

export type TnTitleInstance = InstanceType<typeof Title>
