import type ImageUpload from './image-upload.vue'

export type TnImageUploadInstance = InstanceType<typeof ImageUpload>
