export type StepRectInfo = {
  width: number
  height: number
  left: number
}
