import type Stpes from './steps.vue'
import type StepsItem from './steps-item.vue'

export type TnStepsInstance = InstanceType<typeof Stpes>
export type TnStepsItemInstance = InstanceType<typeof StepsItem>
