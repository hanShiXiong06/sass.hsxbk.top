import type PhotoAlbum from './photo-album.vue'

export type TnPhotoAlbumInstance = InstanceType<typeof PhotoAlbum>
