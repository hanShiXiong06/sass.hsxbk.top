import type Modal from './modal.vue'

export type TnModalInstance = InstanceType<typeof Modal>
