import type Button from './button.vue'

export type TnButtonInstance = InstanceType<typeof Button>
