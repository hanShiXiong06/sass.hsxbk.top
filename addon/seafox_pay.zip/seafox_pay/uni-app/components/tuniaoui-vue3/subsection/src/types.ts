export interface SubsectionItemRect {
  left: number
  width: number
}

export type SubsectionSliderRect = SubsectionItemRect
