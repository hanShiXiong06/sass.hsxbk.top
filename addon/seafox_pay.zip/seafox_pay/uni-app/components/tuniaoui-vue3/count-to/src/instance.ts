import type CountTo from './count-to.vue'

export type TnCountToInstance = InstanceType<typeof CountTo>
