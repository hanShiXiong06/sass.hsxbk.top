import type Switch from './switch.vue'

export type TnSwitchInstance = InstanceType<typeof Switch>
