import type Rate from './rate.vue'

export type TnRateInstance = InstanceType<typeof Rate>
