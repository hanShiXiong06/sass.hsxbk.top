import type IndexList from './index-list.vue'

export type TnIndexListInstance = InstanceType<typeof IndexList>
