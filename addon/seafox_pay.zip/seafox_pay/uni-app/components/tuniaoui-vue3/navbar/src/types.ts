export type NavbackButtonType = 'single' | 'multi' | 'text' | 'custom' | 'none'
