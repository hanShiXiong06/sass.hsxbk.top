import type Navbar from './navbar.vue'

export type TnNavbarInstance = InstanceType<typeof Navbar>
