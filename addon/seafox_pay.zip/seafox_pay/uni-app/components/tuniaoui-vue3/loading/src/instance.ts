import type Loading from './loading.vue'

export type LoadingInstance = InstanceType<typeof Loading>
