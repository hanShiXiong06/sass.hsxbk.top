import type NoticeBar from './notice-bar.vue'

export type TnNoticeBarInstance = InstanceType<typeof NoticeBar>
