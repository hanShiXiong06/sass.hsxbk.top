import type Keyboard from './keyboard.vue'

export type TnKeyboardInstance = InstanceType<typeof Keyboard>
