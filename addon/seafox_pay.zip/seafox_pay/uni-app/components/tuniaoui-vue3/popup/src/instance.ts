import type Popup from './popup.vue'

export type TnPopupInstance = InstanceType<typeof Popup>
