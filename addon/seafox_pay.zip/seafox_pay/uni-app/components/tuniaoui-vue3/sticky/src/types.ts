export type StickyRectInfo = {
  width: string | number
  height: string | number
  left: number
}
