import type Sticky from './sticky.vue'

export type TnStickyInstance = InstanceType<typeof Sticky>
