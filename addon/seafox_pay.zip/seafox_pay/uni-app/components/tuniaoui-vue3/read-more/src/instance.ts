import type ReadMore from './read-more.vue'

export type TnReadMoreInstance = InstanceType<typeof ReadMore>
