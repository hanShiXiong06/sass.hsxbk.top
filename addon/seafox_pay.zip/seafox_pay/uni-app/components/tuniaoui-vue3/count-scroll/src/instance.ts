import type CountScroll from './count-scroll.vue'

export type TnCountScrollInstance = InstanceType<typeof CountScroll>
