import type List from './list-item.vue'

export type TnListItemInstance = InstanceType<typeof List>
