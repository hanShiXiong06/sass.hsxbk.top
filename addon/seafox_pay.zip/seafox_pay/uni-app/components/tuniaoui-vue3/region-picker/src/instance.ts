import type RegionPicker from './region-picker.vue'

export type TnRegionPickerInstance = InstanceType<typeof RegionPicker>
