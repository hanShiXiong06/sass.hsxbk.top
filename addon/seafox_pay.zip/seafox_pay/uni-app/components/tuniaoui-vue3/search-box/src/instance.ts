import type SearchBox from './search-box.vue'

export type TnSearchBoxInstance = InstanceType<typeof SearchBox>
