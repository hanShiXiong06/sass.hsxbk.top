import type Icon from './icon.vue'

export type IconInstance = InstanceType<typeof Icon>
