import type LineProgress from './line-progress.vue'

export type TnLineProgressInstance = InstanceType<typeof LineProgress>
