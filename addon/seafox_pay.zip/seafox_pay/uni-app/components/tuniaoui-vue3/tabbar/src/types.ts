export interface TabbarItemRect {
  width: number
  height: number
  left: number
  maxWidth?: number
}
