import type CountDown from './count-down.vue'

export type TnCountDownInstance = InstanceType<typeof CountDown>
