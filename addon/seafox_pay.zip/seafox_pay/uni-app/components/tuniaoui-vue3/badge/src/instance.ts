import type Badge from './badge.vue'

export type BadgeInstance = InstanceType<typeof Badge>
