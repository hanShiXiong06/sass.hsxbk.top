import type TnInput from './input.vue'

export type TnInputInstance = InstanceType<typeof TnInput>
