export interface TabsItemRect {
  width: number
  height: number
  left: number
}

export type TabsRect = TabsItemRect
export type TabsBarRect = TabsItemRect
