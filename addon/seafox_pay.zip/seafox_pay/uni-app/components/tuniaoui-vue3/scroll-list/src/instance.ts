import type ScrollList from './scroll-list.vue'

export type TnScrollListInstance = InstanceType<typeof ScrollList>
