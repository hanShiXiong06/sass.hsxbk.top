import type Overlay from './overlay.vue'

export type TnOverlayInstance = InstanceType<typeof Overlay>
