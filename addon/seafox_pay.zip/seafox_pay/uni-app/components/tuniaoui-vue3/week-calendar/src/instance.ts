import type WeekCalendar from './week-calendar.vue'

export type TnWeekCalendarInstance = InstanceType<typeof WeekCalendar>
