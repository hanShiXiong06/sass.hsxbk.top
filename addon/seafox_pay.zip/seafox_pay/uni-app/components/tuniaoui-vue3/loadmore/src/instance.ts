import type Loadmore from './loadmore.vue'

export type TnLoadmoreInstance = InstanceType<typeof Loadmore>
