import type Notify from './notify.vue'

export type TnNotifyInstance = InstanceType<typeof Notify>
