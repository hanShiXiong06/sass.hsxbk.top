import type CircleProgress from './circle-progress.vue'

export type TnCircleProgressInstance = InstanceType<typeof CircleProgress>
