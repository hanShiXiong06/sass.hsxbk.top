import type SwitchTab from './switch-tab.vue'

export type TnSwitchTabInstance = InstanceType<typeof SwitchTab>
