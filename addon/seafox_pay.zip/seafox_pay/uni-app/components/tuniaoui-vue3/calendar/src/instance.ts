import type Calendar from './calendar.vue'

export type TnCalendarInstance = InstanceType<typeof Calendar>
