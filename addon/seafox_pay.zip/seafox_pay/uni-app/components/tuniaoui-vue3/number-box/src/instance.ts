import type NumberBox from './number-box.vue'

export type TnNumberBoxInstance = InstanceType<typeof NumberBox>
