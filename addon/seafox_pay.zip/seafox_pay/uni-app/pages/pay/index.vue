<template>
	<text class="text-[20px]"></text>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { onLoad } from '@dcloudio/uni-app'
import { getPayInfo } from '@/app/api/pay'
import {  redirect } from '@/utils/common'

const payInfo = ref<any>({
    trade_type : '',
    trade_id : ''
})

onLoad((query :any) => {
	console.log(query,query.paySign,'query');
    payInfo.value.trade_type = query.trade_type || ''
    payInfo.value.trade_id = query.trade_id
     // #ifdef MP-WEIXIN
    wx.requestPayment({
        timeStamp: query.timeStamp,
        nonceStr: query.nonceStr,
        package: query.package_key + '=' + query.package_value,
        signType: query.signType,
        paySign: query.paySign + '==',
		success: () => {
			// toPayResult()
		},
		fail: (err) => {
			console.log(err,'err');
            // toPayResult()
		},
		complete: () => {
            toPayResult()
		}
	})
    // #endif

    // #ifdef MP-ALIPAY
    my.tradePay({
	    tradeNO: query.tradeNO,
	    success: (payRes) => {
		    if (payRes.resultCode == '9000') {
		    		toPayResult()
		    } 
		},
		fail: (err) => {}
		})
		// #endif
})

const toPayResult = ()=> {
    redirect({ url: '/app/pages/pay/result', param: { trade_type: payInfo.value?.trade_type, trade_id: payInfo.value?.trade_id }, mode: 'redirectTo' })
}
</script>
<style lang="scss" scoped>

</style>
