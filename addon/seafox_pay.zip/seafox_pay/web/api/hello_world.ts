
/**
 * hello world
 */
export function getHelloWorld() {
    return request.get('seafox_pay/hello_world')
}

