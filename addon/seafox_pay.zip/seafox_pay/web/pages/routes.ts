export default [
    {
        path: "/seafox_pay/hello_world/index",
        component: () => import('~/addon/seafox_pay/pages/hello_world/index.vue')
    }
]
