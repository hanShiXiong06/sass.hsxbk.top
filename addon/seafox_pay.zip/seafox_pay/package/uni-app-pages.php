<?php
return [
    'pages' => <<<EOT
        // PAGE_BEGIN
                // *********************************** hello world ***********************************
                {
                    "path": "seafox_pay/pages/hello_world/index",
                    "style": {
                        "navigationBarTitleText": "%seafox_pay.pages.hello_world.index%"
                    }
				},
                // *********************************** pay ***********************************
                {
                    "path": "seafox_pay/pages/pay/index",
                    "style": {
                        "navigationBarTitleText": "%seafox_pay.pages.pay.index%"
                    }
				},
				 // *********************************** maidan ***********************************
                {
                    "path": "seafox_pay/pages/maidan/index",
                    "style": {
                        "navigationBarTitleText": "%seafox_pay.pages.maidan.index%"
                    }
				},
                // PAGE_END
EOT
];