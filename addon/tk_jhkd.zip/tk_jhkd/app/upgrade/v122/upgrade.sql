ALTER TABLE tkjhkd_order_delivery
    ADD COLUMN channel_id VARCHAR(255);
