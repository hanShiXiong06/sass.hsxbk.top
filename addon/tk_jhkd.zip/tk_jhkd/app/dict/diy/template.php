<?php

return [
    'DIY_TK_JHKD_INDEX' => [
        'title' => '快递首页',
        'page' => '/addon/tk_jhkd/pages/index',
        'action' => 'decorate',
        'type' => 'index'
    ],
];