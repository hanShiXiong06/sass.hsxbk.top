<?php
return [
    [
        'menu_name' => '聚合快递',
        'menu_key' => 'tk_jhkd_admin',
        'menu_short_name' => '聚合快递',
        'parent_key' => '',
        'menu_type' => '1',
        'icon' => 'iconfont-iconyingyongshichang',
        'api_url' => '',
        'router_path' => 'tk_jhkd',
        'view_path' => 'tk_jhkd/admin',
        'methods' => '',
        'sort' => '90',
        'status' => '1',
        'is_show' => '0',
    ],
];