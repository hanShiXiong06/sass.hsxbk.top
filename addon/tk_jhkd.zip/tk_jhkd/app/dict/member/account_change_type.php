<?php

use app\dict\member\MemberAccountTypeDict;

return [
    MemberAccountTypeDict::POINT => [
        //调整
        'tk_jhkd_test' => [
            //名称
            'name' => "tk_jhkd账户变化",
            //是否增加
            'inc' => 1,
            //是否减少
            'dec' => 1,
        ],

    ],
];