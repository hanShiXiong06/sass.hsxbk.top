<template>
    <div class="main-container">
        <el-card class="box-card !border-none" shadow="never">
            后台管理页面
        </el-card>
    </div>
</template>

<script lang="ts" setup>
</script>

<style lang="scss" scoped></style>
