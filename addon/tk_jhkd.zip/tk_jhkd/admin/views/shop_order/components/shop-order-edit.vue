<template>
    <el-dialog v-model="showDialog" :title="formData.id ? t('updateShopOrder') : t('addShopOrder')" width="50%" class="diy-dialog-wrap"
        :destroy-on-close="true">
        <el-form :model="formData" label-width="120px" ref="formRef" :rules="formRules" class="page-form" v-loading="loading">
                <el-form-item :label="t('orderNo')" prop="order_no">
    <el-input v-model="formData.order_no" clearable :placeholder="t('orderNoPlaceholder')" class="input-width" />
</el-form-item>

                <el-form-item :label="t('deliveryId')" >
    <el-input v-model="formData.delivery_id" clearable :placeholder="t('deliveryIdPlaceholder')" class="input-width" />
</el-form-item>

                <el-form-item :label="t('yidaOrderNo')" >
    <el-input v-model="formData.yida_order_no" clearable :placeholder="t('yidaOrderNoPlaceholder')" class="input-width" />
</el-form-item>

                <el-form-item :label="t('orderStatusName')" >
    <el-input v-model="formData.order_status_name" clearable :placeholder="t('orderStatusNamePlaceholder')" class="input-width" />
</el-form-item>

                <el-form-item :label="t('isPick')" >
    <el-input v-model="formData.is_pick" clearable :placeholder="t('isPickPlaceholder')" class="input-width" />
</el-form-item>

                <el-form-item :label="t('isSend')" >
    <el-input v-model="formData.is_send" clearable :placeholder="t('isSendPlaceholder')" class="input-width" />
</el-form-item>

                <el-form-item :label="t('closeTime')" >
    <el-input v-model="formData.close_time" clearable :placeholder="t('closeTimePlaceholder')" class="input-width" />
</el-form-item>

                <el-form-item :label="t('deleteTime')" >
    <el-input v-model="formData.delete_time" clearable :placeholder="t('deleteTimePlaceholder')" class="input-width" />
</el-form-item>

        </el-form>

        <template #footer>
            <span class="dialog-footer">
                <el-button @click="showDialog = false">{{ t('cancel') }}</el-button>
                <el-button type="primary" :loading="loading" @click="confirm(formRef)">{{
                    t('confirm')
                }}</el-button>
            </span>
        </template>
    </el-dialog>
</template>

<script lang="ts" setup>
import { ref, reactive, computed, watch } from 'vue'
import { useDictionary } from '@/app/api/dict'
import { t } from '@/lang'
import type { FormInstance } from 'element-plus'

import { addShopOrder, editShopOrder, getShopOrderInfo, } from '@/addon/tk_jhkd/api/shop_order'

let showDialog = ref(false)
const loading = ref(false)

/**
 * 表单数据
 */
const initialFormData = {
    id: '',
    order_no: '',
    delivery_id: '',
    yida_order_no: '',
    order_status_name: '',
    is_pick: '',
    is_send: '',
    close_time: '',
    delete_time: '',
}
const formData: Record<string, any> = reactive({ ...initialFormData })

const formRef = ref<FormInstance>()

// 表单验证规则
const formRules = computed(() => {
    return {
    order_no: [
        { required: true, message: t('orderNoPlaceholder'), trigger: 'blur' },
        
    ]
,
    delivery_id: [
        { required: true, message: t('deliveryIdPlaceholder'), trigger: 'blur' },
        
    ]
,
    yida_order_no: [
        { required: true, message: t('yidaOrderNoPlaceholder'), trigger: 'blur' },
        
    ]
,
    order_status_name: [
        { required: true, message: t('orderStatusNamePlaceholder'), trigger: 'blur' },
        
    ]
,
    is_pick: [
        { required: true, message: t('isPickPlaceholder'), trigger: 'blur' },
        
    ]
,
    is_send: [
        { required: true, message: t('isSendPlaceholder'), trigger: 'blur' },
        
    ]
,
    close_time: [
        { required: true, message: t('closeTimePlaceholder'), trigger: 'blur' },
        
    ]
,
    delete_time: [
        { required: true, message: t('deleteTimePlaceholder'), trigger: 'blur' },
        
    ]
,
    }
})

const emit = defineEmits(['complete'])

/**
 * 确认
 * @param formEl
 */
const confirm = async (formEl: FormInstance | undefined) => {
    if (loading.value || !formEl) return
    let save = formData.id ? editShopOrder : addShopOrder

    await formEl.validate(async (valid) => {
        if (valid) {
            loading.value = true

            let data = formData

            save(data).then(res => {
                loading.value = false
                showDialog.value = false
                emit('complete')
            }).catch(err => {
                loading.value = false
            })
        }
    })
}

// 获取字典数据
    

    
const setFormData = async (row: any = null) => {
    Object.assign(formData, initialFormData)
    loading.value = true
    if(row){
        const data = await (await getShopOrderInfo(row.id)).data
        if (data) Object.keys(formData).forEach((key: string) => {
            if (data[key] != undefined) formData[key] = data[key]
        })
    }
    loading.value = false
}

// 验证手机号格式
const mobileVerify = (rule: any, value: any, callback: any) => {
    if (value && !/^1[3-9]\d{9}$/.test(value)) {
        callback(new Error(t('generateMobile')))
    } else {
        callback()
    }
}

// 验证身份证号
const idCardVerify = (rule: any, value: any, callback: any) => {
    if (value && !/^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$/.test(value)) {
        callback(new Error(t('generateIdCard')))
    } else {
        callback()
    }
}

// 验证邮箱号
const emailVerify = (rule: any, value: any, callback: any) => {
    if (value && !/\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/.test(value)) {
        callback(new Error(t('generateEmail')))
    } else {
        callback()
    }
}

// 验证请输入整数
const numberVerify = (rule: any, value: any, callback: any) => {
    if (!Number.isInteger(value)) {
        callback(new Error(t('generateNumber')))
    } else {
        callback()
    }
}

defineExpose({
    showDialog,
    setFormData
})
</script>

<style lang="scss" scoped></style>
<style lang="scss">
.diy-dialog-wrap .el-form-item__label{
    height: auto  !important;
}
</style>
